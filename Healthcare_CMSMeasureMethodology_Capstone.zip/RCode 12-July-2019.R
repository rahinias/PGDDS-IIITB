#####################Sequence Of Code - Venkata Nihar Tatavarti#######################################
#Part 2 - Clustering-Based Rating (Unsupervised)
#Part 1 - Supervised Learning-Based Rating
#Part 3 - Recommendations for Hospitals
#######################################################################################################

###################################################Basic Setup#######################################
#Load required libraries using pacman
install.packages("pacman")
pacman::p_load("gtools","RColorBrewer","mira","psych","corrplot","EFAutilities","nFactors","Information","dplyr","ggplot2","ggthemes","caret","gridExtra","cowplot","missForest","xlsx","magrittr","tidyverse","plyr","stringr","ggplot2","lubridate","data.table","sqldf","reshape2","DataExplorer","mice","VIM","reprex",install = TRUE, update = getOption("pac_update"),character.only = FALSE)
pacman::p_library(open = FALSE)
remove(list = ls()) #Clear the Global Environment
setwd("C:/Masters/PGDDS/Capstone/Base Files/Hospital_Revised_FlatFiles_20161110") #set working directory
#Load Facility or Hospital Data to identify required files for measures
ASMFacility <- read.csv("Ambulatory Surgical Measures-Facility.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
compHosp <- read.csv("Complications - Hospital.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
HCAHPSHosp <- read.csv("HCAHPS - Hospital.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
HAIHosp <- read.csv("Healthcare Associated Infections - Hospital.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
HGI <- read.csv("Hospital General Information.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
medicareClaimHosp <- read.csv("Medicare Hospital Spending by Claim.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
medicareClaimPatientHosp <- read.csv("Medicare Hospital Spending per Patient - Hospital.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
imagingHosp <- read.csv("Outpatient Imaging Efficiency - Hospital.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
outProced <- read.csv("Outpatient Procedures - Volume.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
readmissionreduction <- read.csv("READMISSION REDUCTION.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
readmissiondeathHosp <- read.csv("Readmissions and Deaths - Hospital.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
payValueCareHosp <- read.csv("Payment and Value of Care - Hospital.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
strcMeasures <- read.csv("Structural Measures - Hospital.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
TEHosp <- read.csv("Timely and Effective Care - Hospital.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))

###################################################Basic Setup Complete################################


###############Part 2 - Clustering-Based Rating (Unsupervised)#######################################
### Step 1  - Identify Measure Groups & Direction of Measure
### Step 2  - Data clean-up & Understanding based on EDA
### Step 3  - Missing Value Imputation (Using MICE - Predictive Mean Matching)
### Step 4  - Data Normalization
### Step 4.1  - Lower the Better - Scale in inverse direction
### Step 4.2  - Higher the Better - Scale normally
### Step 5  - Outlier Treatment {at 0.125th and the 99.875th percentiles per methodology}
### Step 6  - Factor Analysis for Variable Weights within Measure Group
### Step 7  - Overall score using Standard Weights of Measure Group
### Step 8 - K-Means Clustering to arrive at Five Star Rating
### Step 9 - Confusion Matrix with Unsupervised learning Model CMS Rating Vs 2016 CMS Rating
#######################################################################################################


#######################################################################################################
###Unsupervised Learning (97 Measures considered -> Upgrad Ticket reference 89967 / 89905 / 89926)
#######################################################################################################



#97 Measures considered based on Latest CMS data, load the file as measure dictionary 
Ailment <- c("Structuralmeasures",	"Structuralmeasures",	"Structuralmeasures",	"Structuralmeasures",	"Structuralmeasures",	"Sepsis",	"Cataract",	"Colonoscopy",	"Colonoscopy",	"HeartAttack",	"HeartAttack",	"HeartAttack",	"HeartAttack",	"HeartAttack",	"Emergencydepartment_throughput",	"Emergencydepartment_throughput",	"Emergencydepartment_throughput",	"Emergencydepartment_throughput",	"Emergencydepartment_throughput",	"Emergencydepartment_throughput",	"Emergencydepartment_throughput",	"Emergencydepartment_throughput",	"PreventiveCare",	"PreventiveCare",	"BloodClotPrevention",	"ChildDelivery",	"PreventiveCare",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Infections",	"Infections",	"Infections",	"Infections",	"Infections",	"Infections",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Clinical Episode_Based Payment",	"Clinical Episode_Based Payment",	"Clinical Episode_Based Payment",	"Clinical Episode_Based Payment",	"Clinical Episode_Based Payment",	"Clinical Episode_Based Payment",	"MedicareSpendingPerBeneficiary",	"Paymentmeasures",	"Paymentmeasures",	"Paymentmeasures",	"Paymentmeasures",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care")
Measure_ID <- c("OP_12",	"OP_17",	"OP_25",	"SM_SS_CHECK",	"SM_HS_PATIENT_SAF",	"SEP_1",	"OP_31",	"OP_29",	"OP_30",	"OP_3b",	"OP_5",	"OP_1",	"OP_2",	"OP_4",	"EDV",	"ED_1b",	"ED_2b",	"OP_18b",	"OP_20",	"OP_21",	"OP_22",	"OP_23",	"IMM_2",	"IMM_3_OP_27_FAC_ADHPCT",	"VTE_6",	"PC_01",	"OP_33",	"COMP_HIP_KNEE",	"PSI_90_SAFETY",	"PSI_3_ULCER",	"PSI_4_SURG_COMP",	"PSI_6_IAT_PTX",	"PSI_8_POST_HIP",	"PSI_9_POST_HEM",	"PSI_10_POST_KIDNEY",	"PSI_11_POST_RESP",	"PSI_12",	"PSI_13_POST_SEPSIS",	"PSI_14",	"PSI_15",	"HAI_1",	"HAI_2",	"HAI_3",	"HAI_4",	"HAI_5",	"HAI_6",	"MORT_30_COPD",	"MORT_30_AMI",	"MORT_30_HF",	"MORT_30_PN",	"MORT_30_STK",	"MORT_30_CABG",	"OP_32",	"EDAC_30_AMI",	"EDAC_30_HF",	"EDAC_30_PN",	"READM_30_COPD",	"READM_30_AMI",	"READM_30_HF",	"READM_30_PN",	"READM_30_STK",	"READM_30_CABG",	"READM_30_HIP_KNEE",	"READM_30_HOSP_WIDE",	"OP_8",	"OP_9",	"OP_10",	"OP_11",	"OP_13",	"OP_14",	"CEBP_AA",	"CEBP_CELLULITIS",	"CEBP_CHOLE_CDE",	"CEBP_GI",	"CEBP_KIDNEY_UTI",	"CEBP_SFUSION",	"MSPB_1",	"PAYM_30_AMI",	"PAYM_30_HF",	"PAYM_30_PN",	"PAYM_90_HIP_KNEE",	"H_COMP_1_LINEAR_SCORE",	"H_COMP_2_LINEAR_SCORE",	"H_COMP_4_LINEAR_SCORE",	"H_COMP_5_LINEAR_SCORE",	"H_CLEAN_LINEAR_SCORE",	"H_QUIET_LINEAR_SCORE",	"H_COMP_6_LINEAR_SCORE",	"H_COMP_7_LINEAR_SCORE",	"H_HSP_RATING_LINEAR_SCORE",	"H_RECMND_LINEAR_SCORE",	"HAI_1_SIR",	"HAI_2_SIR",	"HAI_3_SIR",	"HAI_4_SIR",	"HAI_5_SIR",	"HAI_6_SIR")
Measure_Type <- c("Outpatient imaging efficiency",	"Outpatient imaging efficiency",	"Timeliness_of_Care",	"Timeliness_of_Care",	"Patient_Experience",	"Effectiveness_of_Care",	"Effectiveness_of_Care",	"Effectiveness_of_Care",	"Effectiveness_of_Care",	"Timeliness_of_Care",	"Timeliness_of_Care",	"Timeliness_of_Care",	"Timeliness_of_Care",	"Effectiveness_of_Care",	"Effectiveness_of_Care",	"Timeliness_of_Care",	"Timeliness_of_Care",	"Timeliness_of_Care",	"Timeliness_of_Care",	"Timeliness_of_Care",	"Effectiveness_of_Care",	"Effectiveness_of_Care",	"Effectiveness_of_Care",	"Effectiveness_of_Care",	"Effectiveness_of_Care",	"Effectiveness_of_Care",	"Effectiveness_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Mortality",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Value_Of_Care",	"Value_Of_Care",	"Value_Of_Care",	"Value_Of_Care",	"Value_Of_Care",	"Value_Of_Care",	"Value_Of_Care",	"Value_Of_Care",	"Value_Of_Care",	"Value_Of_Care",	"Value_Of_Care",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care")
HBLB <- c("High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"High the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"High the better",	"High the better",	"High the better",	"Lower the better",	"Lower the better",	"High the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better")
Measure_Name <- c("OP_12",	"OP_17",	"OP_25",	"SM_SS_CHECK",	"SM_HS_PATIENT_SAF",	"SEP_1",	"OP_31",	"OP_29",	"OP_30",	"OP_3b",	"OP_5",	"OP_1",	"OP_2",	"OP_4",	"EDV",	"ED_1b",	"ED_2b",	"OP_18b",	"OP_20",	"OP_21",	"OP_22",	"OP_23",	"IMM_2",	"IMM_3_OP_27_FAC_ADHPCT",	"VTE_6",	"PC_01",	"OP_33",	"COMP_HIP_KNEE",	"PSI_90_SAFETY",	"PSI_3_ULCER",	"PSI_4_SURG_COMP",	"PSI_6_IAT_PTX",	"PSI_8_POST_HIP",	"PSI_9_POST_HEM",	"PSI_10_POST_KIDNEY",	"PSI_11_POST_RESP",	"PSI_12",	"PSI_13_POST_SEPSIS",	"PSI_14",	"PSI_15",	"HAI_1",	"HAI_2",	"HAI_3",	"HAI_4",	"HAI_5",	"HAI_6",	"MORT_30_COPD",	"MORT_30_AMI",	"MORT_30_HF",	"MORT_30_PN",	"MORT_30_STK",	"MORT_30_CABG",	"OP_32",	"EDAC_30_AMI",	"EDAC_30_HF",	"EDAC_30_PN",	"READM_30_COPD",	"READM_30_AMI",	"READM_30_HF",	"READM_30_PN",	"READM_30_STK",	"READM_30_CABG",	"READM_30_HIP_KNEE",	"READM_30_HOSP_WIDE",	"OP_8",	"OP_9",	"OP_10",	"OP_11",	"OP_13",	"OP_14",	"CEBP_AA",	"CEBP_CELLULITIS",	"CEBP_CHOLE_CDE",	"CEBP_GI",	"CEBP_KIDNEY_UTI",	"CEBP_SFUSION",	"MSPB_1",	"PAYM_30_AMI",	"PAYM_30_HF",	"PAYM_30_PN",	"PAYM_90_HIP_KNEE",	"H_COMP_1_LINEAR_SCORE",	"H_COMP_2_LINEAR_SCORE",	"H_COMP_4_LINEAR_SCORE",	"H_COMP_5_LINEAR_SCORE",	"H_CLEAN_LINEAR_SCORE",	"H_QUIET_LINEAR_SCORE",	"H_COMP_6_LINEAR_SCORE",	"H_COMP_7_LINEAR_SCORE",	"H_HSP_RATING_LINEAR_SCORE",	"H_RECMND_LINEAR_SCORE",	"HAI_1_SIR",	"HAI_2_SIR",	"HAI_3_SIR",	"HAI_4_SIR",	"HAI_5_SIR",	"HAI_6_SIR")
measureDic <- data.frame(Ailment,Measure_ID,Measure_Type,Measure_Name,HBLB)
#measureDic <- read.csv("revisedMeasureReference18May19.csv",stringsAsFactors = TRUE,header=T, na.strings=c("","NA","Not Available"))

#Identify the files that contain Measures and obtain Measure Scores from Hospital/Facility Data frames
str(ASMFacility) #Does not contain any of required 97 measures, do not consider for processing
str(compHosp) #Contains Measures ID and Score
str(HCAHPSHosp) #Contains Measures ID and Linear Score
str(HAIHosp)#Contains Measures ID and Score
str(HGI) #This is an output of comparison, do not consider for processing
str(medicareClaimHosp) #This is an output of comparison, do not consider for processing
str(medicareClaimPatientHosp)#Contains Measures ID and Score
str(imagingHosp) #Contains Measures ID and Score
str(outProced) #This is an output of comparison, do not consider for processing
str(readmissionreduction) #This is an output of comparison, do not consider for processing
str(readmissiondeathHosp) #Contains Measures ID and Score
str(payValueCareHosp) #This is an output of comparison, do not consider for processing
str(strcMeasures) #Contains Measures ID and Measure response
str(TEHosp)#Contains Measures ID and Score

#Clear unwanted data frames & CSVs from Global Environment
#remove(list=c("ASMFacility", "HGI", "medicareClaimHosp","outProced","readmissionreduction","payValueCareHosp"))

#######################################################################################################
### Step 2  - Data clean-up & Business Understanding through EDA
#######################################################################################################

#Function to check duplicates on combination of Provider ID and Measure ID
df_dups <- function (df_dups){
  df_dups = sum(duplicated(df_dups))
  return(df_dups)
}

df_dups(compHosp[c("Provider.ID", "Measure.ID")]) #No duplicates
df_dups(HCAHPSHosp[c("Provider.ID", "HCAHPS.Measure.ID")]) #No duplicates
df_dups(HAIHosp[c("Provider.ID", "Measure.ID")]) #No duplicates
df_dups(medicareClaimPatientHosp[c("Provider.ID", "Measure.ID")]) #No duplicates
df_dups(imagingHosp[c("Provider.ID", "Measure.ID")]) #No duplicates
df_dups(readmissiondeathHosp[c("Provider.ID", "Measure.ID")]) #No duplicates
df_dups(strcMeasures[c("Provider.ID", "Measure.ID")]) #No duplicates
df_dups(TEHosp[c("Provider.ID", "Measure.ID")]) #No duplicates

#Create data into a long format & standardize Column Headers

names(compHosp) <- gsub("\\.", "_", names(compHosp)) #Replace dots in Column Names with Underscore
tempDF <- sqldf("SELECT T1.Provider_ID, T1.Hospital_Name, T1.City, T1.State, T1.ZIP_Code, T1.Measure_ID, T1.Score,
                T2.Ailment, T2.Measure_Type, T2.Measure_Name, T2.HBLB 
                FROM compHosp T1, measureDic T2
                WHERE T1.Measure_ID = T2.Measure_ID")
allData <- tempDF #Get required measures


names(HCAHPSHosp) <- gsub("\\.", "_", names(HCAHPSHosp))
tempDF <- sqldf("SELECT T1.Provider_ID, T1.Hospital_Name, T1.City, T1.State, T1.ZIP_Code, T1.HCAHPS_Measure_ID as Measure_ID, T1.HCAHPS_Linear_Mean_Value as Score,
                T2.Ailment, T2.Measure_Type, T2.Measure_Name, T2.HBLB 
                FROM HCAHPSHosp T1, measureDic T2
                WHERE T1.HCAHPS_Measure_ID  = T2.Measure_ID")
allData <- rbind(allData,tempDF)

names(HAIHosp) <- gsub("\\.", "_", names(HAIHosp))
tempDF <- sqldf("SELECT T1.Provider_ID, T1.Hospital_Name, T1.City, T1.State, T1.ZIP_Code, T1.Measure_ID, T1.Score,
                T2.Ailment, T2.Measure_Type, T2.Measure_Name, T2.HBLB 
                FROM HAIHosp T1, measureDic T2
                WHERE T1.Measure_ID  = T2.Measure_ID")
allData <- rbind(allData,tempDF)

names(medicareClaimPatientHosp) <- gsub("\\.", "_", names(medicareClaimPatientHosp))
tempDF <- sqldf("SELECT T1.Provider_ID, T1.Hospital_Name, T1.City, T1.State, T1.ZIP_Code, T1.Measure_ID, T1.Score,
                T2.Ailment, T2.Measure_Type, T2.Measure_Name, T2.HBLB 
                FROM medicareClaimPatientHosp T1, measureDic T2
                WHERE T1.Measure_ID  = T2.Measure_ID")
allData <- rbind(allData,tempDF)

names(imagingHosp) <- gsub("\\.", "_", names(imagingHosp))
tempDF <- sqldf("SELECT T1.Provider_ID, T1.Hospital_Name, T1.City, T1.State, T1.ZIP_Code, T1.Measure_ID, T1.Score,
                T2.Ailment, T2.Measure_Type, T2.Measure_Name, T2.HBLB 
                FROM imagingHosp T1, measureDic T2
                WHERE T1.Measure_ID  = T2.Measure_ID")
allData <- rbind(allData,tempDF)

names(readmissiondeathHosp) <- gsub("\\.", "_", names(readmissiondeathHosp))
tempDF <- sqldf("SELECT T1.Provider_ID, T1.Hospital_Name, T1.City, T1.State, T1.ZIP_Code, T1.Measure_ID, T1.Score,
                T2.Ailment, T2.Measure_Type, T2.Measure_Name, T2.HBLB 
                FROM readmissiondeathHosp T1, measureDic T2
                WHERE T1.Measure_ID  = T2.Measure_ID")
allData <- rbind(allData,tempDF)

names(strcMeasures) <- gsub("\\.", "_", names(strcMeasures))

#Convert Structural Measures  into Numeric Score
strcMeasures$Score[strcMeasures$Measure_Response=="Yes" | strcMeasures$Measure_Response=="Y"] <- 100
strcMeasures$Score[strcMeasures$Measure_Response=="No" | strcMeasures$Measure_Response=="N"] <- 0
strcMeasures$Score[strcMeasures$Measure_Response=="Not Available" | strcMeasures$Measure_Response=="Does not have a Cardiac Surgery Program"] <- 0
tempDF <- sqldf("SELECT T1.Provider_ID, T1.Hospital_Name, T1.City, T1.State, T1.ZIP_Code, T1.Measure_ID, T1.Score,
                T2.Ailment, T2.Measure_Type, T2.Measure_Name, T2.HBLB 
                FROM strcMeasures T1, measureDic T2
                WHERE T1.Measure_ID  = T2.Measure_ID")
allData <- rbind(allData,tempDF)

names(TEHosp) <- gsub("\\.", "_", names(TEHosp))
tempDF <- sqldf("SELECT T1.Provider_ID, T1.Hospital_Name, T1.City, T1.State, T1.ZIP_Code, T1.Measure_ID, T1.Score,
                T2.Ailment, T2.Measure_Type, T2.Measure_Name, T2.HBLB 
                FROM TEHosp T1, measureDic T2
                WHERE T1.Measure_ID  = T2.Measure_ID")
allData <- rbind(allData,tempDF)

allData$updatedScore <- allData$Score 
#Emergency Department Convert EDV Scores into Numeric on a scale of 100
allData$updatedScore[allData$updatedScore=="Very High (60,000+ patients annually)"] <- 100 
allData$updatedScore[allData$updatedScore=="High (40,000 - 59,999 patients annually)"] <- 75  
allData$updatedScore[allData$updatedScore=="Medium (20,000 - 39,999 patients annually)"] <- 50
allData$updatedScore[allData$updatedScore=="Low (0 - 19,999 patients annually)"] <- 25
allData$updatedScore[allData$updatedScore=="Not Available"] <- 0
providerMeasureData <- allData #To be used for Evanston Hospital Comparison


#Check structure of Data and Missing Values
plot_str(allData) # Convert required columns into Factors
plot_missing(allData) # 41.5% of data in Updated Score column has NA values. We will need to divide the files by Measure Type and impute each measure as needed
convert2Factor <- c("Provider_ID", "Hospital_Name", "City", "State","ZIP_Code","Measure_ID","Ailment","Measure_Type","Measure_Name","HBLB")
allData %<>%
  mutate_each_(funs(factor(.)),convert2Factor) #Convert Data into Factors
modAllData <- allData[,-7] #Drop Score column
modAllData$updatedScore <- as.numeric(as.character(modAllData$updatedScore)) #Convert Score from Character into Numeric 
plot_str(modAllData) # Convert required columns into Factors
plot_missing(modAllData) # 41.5% of data in Updated Score column has NA values. We will need to divide the files by Measure Type and impute each measure as needed

#keep required Data Frames in Global Environment
#rm(list=setdiff(ls(), c("modAllData", "allData","measureDic")))

#Remove records where Updated Score is NA, this will remove Providers where all measures are NA
sum(sapply(modAllData$updatedScore, function(x) sum(is.na(x))))
modAllData <- modAllData[!(is.na(modAllData$updatedScore)) ,]
sum(sapply(modAllData$updatedScore, function(x) sum(is.na(x))))

#Create Data Frame for 9 Groups in Long Format
EOC_Long <- split(modAllData,modAllData$Measure_Type)[['Effectiveness_of_Care']]
EMI_Long <- split(modAllData,modAllData$Measure_Type)[['Efficient_Use_of_Medical_Imaging']]
MOR_Long <- split(modAllData,modAllData$Measure_Type)[['Mortality']]
OIE_Long <- split(modAllData,modAllData$Measure_Type)[['Outpatient imaging efficiency']]
PEX_Long <- split(modAllData,modAllData$Measure_Type)[['Patient_Experience']]
RAD_Long <- split(modAllData,modAllData$Measure_Type)[['Readmission']]
SOC_Long <- split(modAllData,modAllData$Measure_Type)[['Safety_of_Care']]
TOC_Long <- split(modAllData,modAllData$Measure_Type)[['Timeliness_of_Care']]
VOC_Long <- split(modAllData,modAllData$Measure_Type)[['Value_Of_Care']]

#Convert long to wide format for 9 groups
EOC_Wide <- dcast(EOC_Long,Provider_ID + Hospital_Name + City + State + ZIP_Code ~ Measure_ID, value.var="updatedScore")
EMI_Wide <- dcast(EMI_Long,Provider_ID + Hospital_Name + City + State + ZIP_Code ~ Measure_ID, value.var="updatedScore")
MOR_Wide <- dcast(MOR_Long,Provider_ID + Hospital_Name + City + State + ZIP_Code ~ Measure_ID, value.var="updatedScore")
OIE_Wide <- dcast(OIE_Long,Provider_ID + Hospital_Name + City + State + ZIP_Code ~ Measure_ID, value.var="updatedScore")
PEX_Wide <- dcast(PEX_Long,Provider_ID + Hospital_Name + City + State + ZIP_Code ~ Measure_ID, value.var="updatedScore")
RAD_Wide <- dcast(RAD_Long,Provider_ID + Hospital_Name + City + State + ZIP_Code ~ Measure_ID, value.var="updatedScore")
SOC_Wide <- dcast(SOC_Long,Provider_ID + Hospital_Name + City + State + ZIP_Code ~ Measure_ID, value.var="updatedScore")
TOC_Wide <- dcast(TOC_Long,Provider_ID + Hospital_Name + City + State + ZIP_Code ~ Measure_ID, value.var="updatedScore")
VOC_Wide <- dcast(VOC_Long,Provider_ID + Hospital_Name + City + State + ZIP_Code ~ Measure_ID, value.var="updatedScore")

#No duplicates on Provider ID
sum(duplicated(EOC_Wide$Provider_ID))
sum(duplicated(EMI_Wide$Provider_ID))
sum(duplicated(MOR_Wide$Provider_ID))
sum(duplicated(OIE_Wide$Provider_ID))
sum(duplicated(PEX_Wide$Provider_ID))
sum(duplicated(RAD_Wide$Provider_ID))
sum(duplicated(SOC_Wide$Provider_ID))
sum(duplicated(TOC_Wide$Provider_ID))
sum(duplicated(VOC_Wide$Provider_ID))

###EDA 

# Number of hospitals based on rating


ggplot(HGI,aes(x=Hospital.overall.rating))+geom_bar(fill='Green')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Rating") + ylab("Count ") + ggtitle("Overall Rating")

# 3 % hospitals are rated 1 Star
# 19 % hospitals are rated 2 Star
# 49 % hospitals are rated 3 Star
# 26 % hospitals are rated 4 Star
# 3 % with 5 Star rating


# Hospitals by State

ggplot(HGI,aes(x=State))+geom_bar(fill='red')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("State") + ylab("Count ") + ggtitle("Count of Hospitals by State")


# Hospitals by Ownership

ggplot(HGI,aes(x=Hospital.Ownership))+geom_bar(fill='orange')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Ownership type") + ylab("Count ") + ggtitle("Count of Hospitals by Ownership type")

# Voluntory Non profit , Proprietary and Government - Hospital District or Authority are the top three types of hospitals

# Hospitals by Type

ggplot(HGI,aes(x= Hospital.Type))+geom_bar(fill='magenta')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Type") + ylab("Count ") + ggtitle("Hospital by type")

# 70 % are Acute Care Hospitals

# Emergency Services

ggplot(HGI,aes(x= Emergency.Services))+geom_bar(fill='blue')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Emergency Service") + ylab("Count ") + ggtitle("Emergency Services")

# 93 % hospitals have Emergency Services

# HISTOGRM - For various measures ###
## Inferences are provided in Presentation ####



# Effectiveness of care- Ploting Histograms 

hist(EOC_Wide$IMM_2,breaks = 15,main= " Patients assessed and given influenza vaccination",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col='grey')
hist(EOC_Wide$IMM_3_OP_27_FAC_ADHPCT,breaks = 15,main= " Healthcare workers given influenza vaccination",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col='grey')
hist(EOC_Wide$OP_22,breaks = 15,main= " % of patients who left the emergency department before being seen",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col='grey')
hist(EOC_Wide$OP_23,breaks = 15,main= " % of patients who came to the emergency department with stroke symptoms who received brain scan results within 45 minutes of arrival",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col='grey')
hist(EOC_Wide$OP_29,breaks = 15,main= " %  of patients receiving appropriate recommendation for follow-up screening colonoscopy",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col='grey')
hist(EOC_Wide$OP_30,breaks = 15,main= " % patients with history of polyps receiving follow-up colonoscopy in the appropriate timeframe",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col='grey')
hist(EOC_Wide$OP_4,breaks = 15,main= " Outpatients with chest pain or possible heart attack who received aspirin within 24 hours",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col='grey')
hist(EOC_Wide$PC_01,breaks = 15,main= " % of mothers whose deliveries were scheduled too early (1-2 weeks early)",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col='grey')
hist(EOC_Wide$VTE_6,breaks = 15,main= " Patients who developed a blood clot while in the hospital",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')

# "Efficient_Use_of_Medical_Imaging" - Ploting Histograms 

hist(EMI_Wide$OP_10 ,breaks = 15,main= " Outpatient CT scans of the abdomen ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist(EMI_Wide$OP_11 ,breaks = 15,main= " Outpatient CT scans of the chest  ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist(EMI_Wide$OP_13 ,breaks = 15,main= " Outpatients who got cardiac imaging stress tests ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist(EMI_Wide$OP_14 ,breaks = 15,main= " Outpatients with brain CT scans who got a sinus CT scan at the same time ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist(EMI_Wide$OP_8 ,breaks = 15,main= " Outpatients with low-back pain who had an MRI without trying recommended treatments ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist(EMI_Wide$OP_9 ,breaks = 15,main= " Outpatients who had a follow-up mammogram, breast ultrasound, or breast MRI  ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')

# "Mortality" - Ploting Histograms 

hist( MOR_Wide$MORT_30_AMI ,breaks = 15,main= " Death rate for heart attack patients ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( MOR_Wide$MORT_30_CABG ,breaks = 15,main= " Death rate for coronary artery bypass graft  ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( MOR_Wide$MORT_30_COPD ,breaks = 15,main= " Death rate for chronic obstructive pulmonary disease ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( MOR_Wide$MORT_30_HF ,breaks = 15,main= " Death rate for heart failure patients ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( MOR_Wide$MORT_30_PN ,breaks = 15,main= " Death rate for pneumonia patients ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( MOR_Wide$MORT_30_STK ,breaks = 15,main= " Death rate for stroke patients ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( MOR_Wide$PSI_4_SURG_COMP ,breaks = 15,main= " Deaths among patients with serious treatable complications after surgery ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')

# " Outpatient imaging efficiency" - Ploting Histograms

hist( OIE_Wide$OP_12 ,breaks = 15,main= " Able to receive lab results electronically ",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')
hist( OIE_Wide$OP_17 ,breaks = 15,main= " Able to receive lab results electronically ",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')

# " Patient_Experience" - Ploting Histograms 

hist( PEX_Wide$H_CLEAN_LINEAR_SCORE ,breaks = 15,main= " Patients who reported that their room and bathroom were clean ",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')
hist( PEX_Wide$H_COMP_1_LINEAR_SCORE ,breaks = 15,main= " Patients who reported that their nurses communicated well ",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')
hist( PEX_Wide$H_COMP_2_LINEAR_SCORE ,breaks = 15,main= " Patients who reported that their doctors communicated well ",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')
hist( PEX_Wide$H_COMP_4_LINEAR_SCORE ,breaks = 15,main= " Patients who reported that they received help as soon as they wanted ",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')
hist( PEX_Wide$H_COMP_5_LINEAR_SCORE ,breaks = 15,main= " Patients who reported that staff explained about medicines ",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')
hist( PEX_Wide$H_COMP_6_LINEAR_SCORE ,breaks = 15,main= " Patients who reported that they were given information about what to do during their recovery at home ",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')
hist( PEX_Wide$H_COMP_7_LINEAR_SCORE ,breaks = 15,main= " Patients who understood their care when they left the hospital",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')
hist( PEX_Wide$H_HSP_RATING_LINEAR_SCORE ,breaks = 15,main= " Patients who gave their hospital a rating on a scale from 0 (lowest) to 10 (highest)",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')
hist( PEX_Wide$H_QUIET_LINEAR_SCORE ,breaks = 15,main= " Patients who reported that the area around their room was quiet at night",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')
hist( PEX_Wide$H_RECMND_LINEAR_SCORE ,breaks = 15,main= " Patients who would recommend the hospital to their friends and family",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')

# "Readmission" - Ploting Histograms 

hist( RAD_Wide$READM_30_AMI ,breaks = 15,main= " Hospital return days for heart attack patients",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( RAD_Wide$READM_30_CABG ,breaks = 15,main= " Rate of unplanned readmission for coronary artery bypass graft (CABG) surgery patients",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( RAD_Wide$READM_30_COPD ,breaks = 15,main= " Rate of unplanned readmission for chronic obstructive pulmonary disease (COPD) patients",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( RAD_Wide$READM_30_HF ,breaks = 15,main= " Hospital return days for heart failure patients",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( RAD_Wide$READM_30_HIP_KNEE ,breaks = 15,main= " Rate of unplanned readmission after hip/knee surgery",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( RAD_Wide$READM_30_HOSP_WIDE ,breaks = 15,main= " Rate of unplanned readmission after discharge from hospital (hospital-wide)",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( RAD_Wide$READM_30_PN ,breaks = 15,main= " ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( RAD_Wide$READM_30_STK ,breaks = 15,main= "Rate of unplanned readmission for stroke patients ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')

# "Safety_of_Care" - Ploting Histograms 

hist( SOC_Wide$HAI_1_SIR ,breaks = 15 ,main= "Central line-associated bloodstream infections (CLABSI) ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( SOC_Wide$HAI_2_SIR ,breaks = 15,main= "Catheter-associated urinary tract infections (CAUTI) ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( SOC_Wide$HAI_3_SIR ,breaks = 15,main= "Surgical site infections from colon surgery (SSI: Colon) ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( SOC_Wide$HAI_4_SIR ,breaks = 15,main= "Surgical site infections from abdominal hysterectomy (SSI: Hysterectomy) ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( SOC_Wide$HAI_5_SIR ,breaks = 15,main= "Methicillin-resistant Staphylococcus Aureus ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( SOC_Wide$HAI_6_SIR ,breaks = 15,main= "Clostridium difficile�(C.diff.) Laboratory-identified Events (Intestinal infections) ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( SOC_Wide$PSI_13_POST_SEPSIS ,breaks = 15,main= "Blood stream infection after surgery ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( SOC_Wide$PSI_3_ULCER ,breaks = 15,main= "Pressure sores ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( SOC_Wide$PSI_6_IAT_PTX ,breaks = 15,main= "Collapsed lung due to medical treatment ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( SOC_Wide$PSI_8_POST_HIP ,breaks = 15,main= "Surgical site infections from colon surgery (SSI: Colon) ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( SOC_Wide$PSI_90_SAFETY ,breaks = 15,main= "Serious complications ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')



# "Timeliness_of_Care" - Ploting Histograms 

hist( TOC_Wide$ED_1b ,breaks = 15,main= "Average (median) time patients spent in the emergency department, before they were admitted  ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( TOC_Wide$ED_2b ,breaks = 15,main= "Average (median) time patients spent in the emergency department, after the doctor decided to admit  ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( TOC_Wide$OP_1 ,breaks = 15,main= "Average (median) number of minutes before outpatients with chest pain or possible heart attack  ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( TOC_Wide$OP_18b ,breaks = 15,main= "Average (median) time patients spent in the emergency departmen  ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( TOC_Wide$OP_2 ,breaks = 15,main= "Outpatients with chest pain or possible heart attack who got drugs to break up blood clots ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( TOC_Wide$OP_20 ,breaks = 15,main= "Average time patients spent in the emergency department before they were seen by a healthcare professional",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( TOC_Wide$OP_21 ,breaks = 15,main= "Average time patients who came to the emergency department with broken bones had to wait before getting pain medication ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( TOC_Wide$OP_25 ,breaks = 15,main= "Uses outpatient safe surgery checklist ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( TOC_Wide$OP_3b ,breaks = 15,main= "Average number of minutes before outpatients with chest pain or possible heart attack who needed specialized care were transferred to another hospital ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( TOC_Wide$OP_5 ,breaks = 15,main= "Average number of minutes before outpatients with chest pain or possible heart attack got an ECG ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')
hist( TOC_Wide$SM_SS_CHECK ,breaks = 15,main= "Uses inpatient safe surgery checklist ",xlab = "Scoring (Higher the better)", ylab = "frequecncy", col= 'grey')


# "Value_Of_Care" - Ploting Histograms 

hist( VOC_Wide$MSPB_1 ,breaks = 15,main= "Medicare Spending Per Beneficiary  ",xlab = "Scoring (Lower the better)", ylab = "frequecncy", col= 'grey')


#######################################################################################################
### Step 3  - Missing Value Imputation (Using MICE - Predictive Mean Matching)
###Missing Value imputation for Numeric Variables using Mice - Predictive Mean Matching https://www.r-bloggers.com/imputing-missing-data-with-r-mice-package/
#######################################################################################################

#Identify Columns to drop based on Missing Values Plot recommendation
plot_missing(EOC_Wide,title="Effectiveness of Care") # Impute Missing Values for all Measures with NAs
plot_missing(EMI_Wide,title="Effectiveness of Medical Imaging") # Impute Missing Values for all Measures with NAs
plot_missing(MOR_Wide,title="Mortality") # Impute Missing Values for all Measures with NAs
plot_missing(OIE_Wide,title="Outpatient imaging efficiency") # Impute Missing Values for all Measures with NAs
plot_missing(PEX_Wide,title="Patient Experience") # Impute Missing Values for all Measures with NAs
plot_missing(RAD_Wide,title="Readmission") # Impute Missing Values for all Measures with NAs
plot_missing(SOC_Wide,title="Safety of Care") # Impute Missing Values for all Measures with NAs
plot_missing(TOC_Wide,title="Timeliness of Care") # Drop measures OP_3b, OP_2, OP_1 based on recommendation, Impute all other missing values 
plot_missing(VOC_Wide,title="Value of Care") # Impute Missing Values for all Measures with NAs
TOC_Wide[,c('OP_3b','OP_2','OP_1')] <- list(NULL)#Drop Measures identified above  OP_3b, OP_2, OP_1

EOC_Wide_MIS <- subset(EOC_Wide, select = -c(Provider_ID,Hospital_Name,City,State,ZIP_Code))
md.pattern(EOC_Wide_MIS)
mice_plot <- aggr(EOC_Wide_MIS, col=c('navyblue','yellow'),
                    numbers=TRUE, sortVars=TRUE,
                    labels=names(EOC_Wide_MIS), cex.axis=.7,
                    gap=3, ylab=c("Missing data","Pattern"))
summary(EOC_Wide_MIS)
imputed_Data <- mice(EOC_Wide_MIS, m=5, maxit = 50, method = 'pmm', seed = 500)
summary(imputed_Data)
fit <- with(data = imputed_Data, exp = lm(EDV ~ IMM_2 + IMM_3_OP_27_FAC_ADHPCT + + OP_22 + OP_23 + OP_29 + OP_30 + OP_4 + PC_01 + VTE_6)) #build predictive model
combine <- pool(fit) #combine results of all 5 models
summary(combine)
xyplot(imputed_Data,EDV ~ PC_01 + VTE_6,pch=18,cex=1)
densityplot(imputed_Data)
stripplot(imputed_Data, pch = 20, cex = 1.2)
plot(imputed_Data)
EOC_Model <- complete(imputed_Data,1)
sapply(EOC_Model, function(x) sum(is.na(x))) #All Missing Values Imputed

#EMI_Wide
WideMissingData <- subset(EMI_Wide, select = -c(Provider_ID,Hospital_Name,City,State,ZIP_Code))
imputed_Data <- mice(WideMissingData, m=5, maxit = 50, method = 'pmm', seed = 500) #build predictive model
summary(WideMissingData)
fit <- with(data = imputed_Data, exp = lm(OP_10 ~ OP_11 + OP_13 + OP_14 + OP_8 + OP_9))
combine <- pool(fit) #combine results of all 5 models
EMI_Model <- complete(imputed_Data,1) # Picks missing value with least variance
densityplot(imputed_Data)
sapply(EMI_Model, function(x) sum(is.na(x))) #All Missing Values Imputed

#MOR_Wide
WideMissingData <- subset(MOR_Wide, select = -c(Provider_ID,Hospital_Name,City,State,ZIP_Code))
imputed_Data <- mice(WideMissingData, m=5, maxit = 50, method = 'pmm', seed = 500)
#build predictive model
summary(WideMissingData)
fit <- with(data = imputed_Data, exp = lm(MORT_30_AMI ~ MORT_30_CABG + MORT_30_COPD + MORT_30_HF + MORT_30_PN + MORT_30_STK + PSI_4_SURG_COMP))
combine <- pool(fit) #combine results of all 5 models
MOR_Model <- complete(imputed_Data,1) # Picks missing value with least variance
densityplot(imputed_Data)
sapply(MOR_Model, function(x) sum(is.na(x))) #All Missing Values Imputed

#OIE_Wide
WideMissingData <- subset(OIE_Wide, select = -c(Provider_ID,Hospital_Name,City,State,ZIP_Code))
imputed_Data <- mice(WideMissingData, m=5, maxit = 50, method = 'pmm', seed = 500) #build predictive model
summary(WideMissingData)
fit <- with(data = imputed_Data, exp = lm(OP_12 ~ OP_17))
combine <- pool(fit) #combine results of all 5 models
OIE_Model <- complete(imputed_Data,1) # Picks missing value with least variance
sapply(OIE_Model, function(x) sum(is.na(x))) #All Missing Values Imputed
densityplot(imputed_Data)

#PEX_Wide has no missing values
PEX_Model <- subset(PEX_Wide, select = -c(Provider_ID,Hospital_Name,City,State,ZIP_Code))
sapply(PEX_Model, function(x) sum(is.na(x))) #All Missing Values Imputed

#RAD_Wide
WideMissingData <- subset(RAD_Wide, select = -c(Provider_ID,Hospital_Name,City,State,ZIP_Code))
imputed_Data <- mice(WideMissingData, m=5, maxit = 50, method = 'pmm', seed = 500) #build predictive model
summary(WideMissingData)
fit <- with(data = imputed_Data, exp = lm(READM_30_AMI ~ READM_30_CABG + READM_30_COPD + READM_30_HF + READM_30_HIP_KNEE + READM_30_HOSP_WIDE + READM_30_PN + READM_30_STK))
combine <- pool(fit) #combine results of all 5 models
RAD_Model <- complete(imputed_Data,1) # Picks missing value with least variance
sapply(RAD_Model, function(x) sum(is.na(x))) #All Missing Values Imputed
densityplot(imputed_Data)

#SOC_Wide
WideMissingData <- subset(SOC_Wide, select = -c(Provider_ID,Hospital_Name,City,State,ZIP_Code))
imputed_Data <- mice(WideMissingData, m=5, maxit = 50, method = 'pmm', seed = 500)#build predictive model
summary(WideMissingData)
fit <- with(data = imputed_Data, exp = lm(COMP_HIP_KNEE ~ HAI_1_SIR + HAI_2_SIR + HAI_3_SIR + HAI_4_SIR + HAI_5_SIR + HAI_6_SIR + PSI_13_POST_SEPSIS + PSI_3_ULCER + PSI_6_IAT_PTX + PSI_8_POST_HIP + PSI_90_SAFETY))
combine <- pool(fit) #combine results of all 5 models
SOC_Model <- complete(imputed_Data,1) # Picks missing value with least variance
sapply(SOC_Model, function(x) sum(is.na(x))) #All Missing Values Imputed
#PSI_8_POST_HIP still has 819 missing values, #PSI_8_POST_HIP still has missing values, we may have to drop the column, will have to validate post Normalization
#We impute these through Median Imputation
tempImputation <- SOC_Model$PSI_8_POST_HIP
tempImputation <- sapply(tempImputation,function(x) {
  if(is.numeric(x)) ifelse(is.na(x),median(x,na.rm=T),x) else x})
SOC_Model$PSI_8_POST_HIP <- tempImputation
#densityplot(imputed_Data)

#TOC_Wide
WideMissingData <- subset(TOC_Wide, select = -c(Provider_ID,Hospital_Name,City,State,ZIP_Code))
imputed_Data <- mice(WideMissingData, m=5, maxit = 50, method = 'pmm', seed = 500) #build predictive model
summary(WideMissingData)
fit <- with(data = imputed_Data, exp = lm(ED_1b ~  ED_2b + OP_18b + OP_20 + OP_21 + OP_25 + OP_5 + SM_SS_CHECK))
combine <- pool(fit) #combine results of all 5 models
TOC_Model <- complete(imputed_Data,1) # Picks missing value with least variance
sapply(TOC_Model, function(x) sum(is.na(x))) #All Missing Values Imputed
densityplot(imputed_Data)

#VOC_Wide has no missing values
VOC_Model <- subset(VOC_Wide, select = -c(Provider_ID,Hospital_Name,City,State,ZIP_Code))

#####################Data for RF##############
EMI_Model_RF<-EMI_Model
EOC_Model_RF<-EOC_Model
MOR_Model_RF<-MOR_Model
OIE_Model_RF<-OIE_Model
PEX_Model_RF<-PEX_Model
RAD_Model_RF<-RAD_Model
SOC_Model_RF<-SOC_Model
TOC_Model_RF<-TOC_Model
VOC_Model_RF<-VOC_Model


#######################################################################################################
### Step 4  - Data Normalization
#######################################################################################################

### Step 4.1  - Lower the Better - Scale in inverse direction,Standardising the measures so that the mean is 0 and standard deviation is 1.
normalizeLB <- function(inputDF) {
              return( (mean(inputDF, na.rm = T) -  inputDF)/(sd(inputDF, na.rm = T)) )
}

### Step 4.2  - Higher the Better - Scale normally
normalizeHB <- function(inputDF) {
              return( ( inputDF - mean(inputDF, na.rm = T) )/(sd(inputDF, na.rm = T)) )
}#Higher the better 

#Value_Of_Care is Lower the Better for Measure MSPB_1
VOC_Model <- sapply(VOC_Model,normalizeLB)

#Timeliness_of_Care has OP_25 & SM_SS_CHECK Higher the better measures, while rest are lower the better
TOC_Model[,c(1,2,3,4,5,7)] <- sapply(TOC_Model[,c(1,2,3,4,5,7)],normalizeLB)
TOC_Model[,c(6,8)] <- sapply(TOC_Model[,c(6,8)],normalizeHB)

#Safety_of_Care has all Lower the better values
SOC_Model <- sapply(SOC_Model,normalizeLB) #We identified that PSI_8_POST_HIP to be validated during Normalization as part of Missing Value Imputation
sum(sapply(SOC_Model[,11], function(x) sum(is.na(x)))) #SOC Model has NaN and NA, we have 3685 NAs - Drop the measure PSI_8_POST_HIP
SOC_Model <- SOC_Model[,-11]

#Readmission has all Lower the better values
RAD_Model <- sapply(RAD_Model,normalizeLB)

#Patient_Experience has all Higher the better values
PEX_Model <- sapply(PEX_Model,normalizeHB)

#Outpatient imaging efficiency has all Higher the better values
OIE_Model <- sapply(OIE_Model,normalizeHB)

#Mortality has all Lower the better values
MOR_Model <- sapply(MOR_Model,normalizeLB)

#Efficient_Use_of_Medical_Imaging has all Lower the better values
EMI_Model <- sapply(EMI_Model,normalizeLB)

#Effectiveness_of_Care EDV, OP_22, VTE_6, PC_01 are lower the better, other measures are higher the better
EOC_Model[,c(1,4,9,10)] <- sapply(EOC_Model[,c(1,4,9,10)],normalizeLB)
EOC_Model[,c(2,3,5,6,7,8)] <- sapply(EOC_Model[,c(2,3,5,6,7,8)],normalizeHB)

#######################################################################################################
### Step 5  - Outlier Treatment {at 0.125th and the 99.875th percentiles per methodology}
#######################################################################################################

#Outlier treatment at 0.125th and the 99.875th percentiles per methodology
imputedOutliers <- function(passArgdataframe){
  for (col in 1:(ncol(passArgdataframe))){
    qntl = quantile(passArgdataframe[, col], probs = seq(0, 1, 0.00001), na.rm = T)
    passArgdataframe[, col][which(passArgdataframe[, col] <= qntl[0.00126*length(qntl)])] <- qntl[0.00126*length(qntl)]
    passArgdataframe[, col][which(passArgdataframe[, col] >= qntl[0.99876*length(qntl)])] <- qntl[0.99876*length(qntl)]
  }
  return(passArgdataframe)
}

VOC_Model <- data.frame(imputedOutliers(VOC_Model))
TOC_Model <- data.frame(imputedOutliers(TOC_Model))
SOC_Model <- data.frame(imputedOutliers(SOC_Model))
RAD_Model <- data.frame(imputedOutliers(RAD_Model))
PEX_Model <- data.frame(imputedOutliers(PEX_Model))
OIE_Model <- data.frame(imputedOutliers(OIE_Model))
MOR_Model <- data.frame(imputedOutliers(MOR_Model))
EMI_Model <- data.frame(imputedOutliers(EMI_Model))
EOC_Model <- data.frame(imputedOutliers(EOC_Model))

#correlation analysis & Cumulative Variance

M <-cor(EOC_Model)
corrplot(M, type="upper", order="hclust",
         col=brewer.pal(n=8, name="RdYlBu"))
M <-cor(EMI_Model)
corrplot(M, type="upper", order="hclust",
         col=brewer.pal(n=8, name="RdYlBu"))
M <-cor(MOR_Model)
corrplot(M, type="upper", order="hclust",
         col=brewer.pal(n=8, name="RdYlBu"))
M <-cor(OIE_Model)
corrplot(M, type="upper", order="hclust",
         col=brewer.pal(n=8, name="RdYlBu"))
M <-cor(PEX_Model)
corrplot(M, type="upper", order="hclust",
         col=brewer.pal(n=8, name="RdYlBu"))
M <-cor(RAD_Model)
corrplot(M, type="upper", order="hclust",
         col=brewer.pal(n=8, name="RdYlBu"))
M <-cor(SOC_Model)
corrplot(M, type="upper", order="hclust",
         col=brewer.pal(n=8, name="RdYlBu"))
M <-cor(TOC_Model)
corrplot(M, type="upper", order="hclust",
         col=brewer.pal(n=8, name="RdYlBu"))

#######################################################################################################
### Step 8  - Factor Analysis for Variable Weights within Measure Group https://www.personality-project.org/r/psych/help/factor.scores.html
#######################################################################################################

grp_scr_fun <- function(grp_df) {
  fa <- factanal(grp_df, factors = 2,rotation = "varimax")
  weights<-as.matrix(fa$loadings/sum(fa$loadings)) # Formula to Normalize loadinng to get Weights
  fa_new_grp <- grp_df
  fa_new_grp[,"grp_score"] <- apply(grp_df, 1, function(x) sum(x * weights) / length(weights)) # Generate Weighted Score for the Groups
  return(fa_new_grp)
}

#Drop EDV as it is Inversely Proportional
EOC_Model <- EOC_Model[,-1]
EOC_Wide <- EOC_Wide[,-6]

fa_EOC <-grp_scr_fun(EOC_Model) #2 Factors
fa_EMI <-grp_scr_fun(EMI_Model) #2 Factors
fa_MOR <-grp_scr_fun(MOR_Model) #2 Factors
fa_PEX <-grp_scr_fun(PEX_Model) #2 Factors
fa_RAD <-grp_scr_fun(RAD_Model) #2 Factors
fa_SOC <-grp_scr_fun(SOC_Model) #2 Factors
fa_TOC <-grp_scr_fun(TOC_Model) #2 Factors


EOCGroupScore <- cbind(EOC_Wide,fa_EOC)
EMIGroupScore <- cbind(EMI_Wide,fa_EMI)
MORGroupScore <- cbind(MOR_Wide,fa_MOR)
PEXGroupScore <- cbind(PEX_Wide,fa_PEX)
RADGroupScore <- cbind(RAD_Wide,fa_RAD)
SOCGroupScore <- cbind(SOC_Wide,fa_SOC)
TOCGroupScore <- cbind(TOC_Wide,fa_TOC)

HospitalData <- read.csv("Hospital General Information.csv",stringsAsFactors = TRUE,header=T, na.strings=c("","NA"))
names(HospitalData)[1] <- "Provider_ID"
names(HospitalData)[13] <- "Hospital_overall_rating"
CMSHospData <- HospitalData[,c(1,13)]
names(HospitalData) <- gsub("\\.", "_", names(HospitalData))
HospitalData <- HospitalData[,-c(12:ncol(HospitalData))]

tempDF <- EOCGroupScore[,c("Provider_ID","grp_score" )]
names(tempDF)[1] <- "Provider_ID"
HospitalData <- merge( HospitalData,tempDF, by="Provider_ID", all=T)
names(HospitalData)[12] <- "EOC_Score"
sum(sapply(HospitalData$EOC_Score, function(x) sum(is.na(x)))) #488 Hospitals do not have EOC Score

tempDF <- EMIGroupScore [,c("Provider_ID","grp_score" )]
names(tempDF)[1] <- "Provider_ID"
HospitalData <- merge( HospitalData,tempDF, by="Provider_ID", all=T)
names(HospitalData)[13] <- "EMI_Score"
sum(sapply(HospitalData$EMI_Score, function(x) sum(is.na(x)))) #1035 Hospitals do not have EMI Score

tempDF <- MORGroupScore  [,c("Provider_ID","grp_score" )]
names(tempDF)[1] <- "Provider_ID"
HospitalData <- merge( HospitalData,tempDF, by="Provider_ID", all=T)
names(HospitalData)[14] <- "MOR_Score"
sum(sapply(HospitalData$MOR_Score, function(x) sum(is.na(x)))) #685 Hospitals do not have MOR Score

tempDF <- PEXGroupScore   [,c("Provider_ID","grp_score" )]
names(tempDF)[1] <- "Provider_ID"
HospitalData <- merge( HospitalData,tempDF, by="Provider_ID", all=T)
names(HospitalData)[15] <- "PEX_Score"
sum(sapply(HospitalData$PEX_Score, function(x) sum(is.na(x)))) #1310 Hospitals do not have PEX Score

tempDF <- RADGroupScore    [,c("Provider_ID","grp_score" )]
names(tempDF)[1] <- "Provider_ID"
HospitalData <- merge( HospitalData,tempDF, by="Provider_ID", all=T)
names(HospitalData)[16] <- "RAD_Score"
sum(sapply(HospitalData$RAD_Score, function(x) sum(is.na(x)))) #403 Hospitals do not have RAD Score

tempDF <- SOCGroupScore     [,c("Provider_ID","grp_score" )]
names(tempDF)[1] <- "Provider_ID"
HospitalData <- merge( HospitalData,tempDF, by="Provider_ID", all=T)
names(HospitalData)[17] <- "SOC_Score"
sum(sapply(HospitalData$SOC_Score, function(x) sum(is.na(x)))) #1133 Hospitals do not have SOC Score

tempDF <- TOCGroupScore      [,c("Provider_ID","grp_score" )]
names(tempDF)[1] <- "Provider_ID"
HospitalData <- merge( HospitalData,tempDF, by="Provider_ID", all=T)
names(HospitalData)[18] <- "TOC_Score"
sum(sapply(HospitalData$TOC_Score, function(x) sum(is.na(x)))) #663 Hospitals do not have TOC Score



HospitalData$NotEligible <- ifelse(is.na(HospitalData$MOR_Score) & is.na(HospitalData$RAD_Score) & is.na(HospitalData$SOC_Score),
                                   as.numeric(0),
                                   as.numeric(1)) #CMS scores are not computed for Hospitals without Outcome groups (Mortality, Safety of Care, and Readmission)

#######################################################################################################
### Step 7  - Overall score using Standard Weights of Measure Group
#######################################################################################################

#Calculate Final Score & consider Re-proportioning Group Weights
denominator <- 100
M1 <- 0 #EOC
M2 <- 0 #EMI
M3 <- 0 #MOR
M4 <- 0 #PEX
M5 <- 0 #RAD
M6 <- 0 #SOC
M7 <- 0 #TOC

for (row in 1:nrow(HospitalData)) { #For each row in HospitalData Data frame
  
  if (HospitalData[row,19] == 1)  { #If Eligible for Star Rating
    
    denominator <- 100
    
    if (is.na(HospitalData[row,"EOC_Score"]) == TRUE) { 
      denominator <- denominator - 4
      M1 <- 0
    } else {
      M1 <- round(HospitalData[row,"EOC_Score"],4)
    }
    
    if (is.na(HospitalData[row,"EMI_Score"]) == TRUE) { 
      denominator <- denominator - 4
      M2 <- 0
    } else {
      M2 <- round(HospitalData[row,"EMI_Score"],4)
    }
    
    if (is.na(HospitalData[row,"MOR_Score"]) == TRUE) { 
      denominator <- denominator - 22
      M3 <- 0
    } else {
      M3 <- round(HospitalData[row,"MOR_Score"],4)
    }
    
    if (is.na(HospitalData[row,"PEX_Score"]) == TRUE) { 
      denominator <- denominator - 22
      M4 <- 0
    } else {
      M4 <- round(HospitalData[row,"PEX_Score"],4)
    }
    
    if (is.na(HospitalData[row,"RAD_Score"]) == TRUE) { 
      denominator <- denominator - 22 
      M5 <- 0
    } else {
      M5 <- round(HospitalData[row,"RAD_Score"],4)
    }
    
    
    if (is.na(HospitalData[row,"SOC_Score"]) == TRUE) { 
      denominator <- denominator - 22
      M6 <- 0
    } else {
      M6 <- round(HospitalData[row,"SOC_Score"],4)
    }
    
    if (is.na(HospitalData[row,"TOC_Score"]) == TRUE) { 
      denominator <- denominator - 4
      M7 <- 0
    } else {
      M7 <- round(HospitalData[row,"TOC_Score"],4)
    }
    
    
    HospitalData[row,"OverallRating"] <-  round(((M1 * 100 * (4/denominator)) + 
                                                   (M2 * 100 * (4/denominator)) + 
                                                   (M3 * 100 * (22/denominator)) + 
                                                   (M4 * 100 * (22/denominator)) + 
                                                   (M5 * 100 * (22/denominator)) + 
                                                   (M6 * 100 * (22/denominator)) + 
                                                   (M7 * 100 * (4/denominator))),4)
    
  } else {
    HospitalData[row,"OverallRating"] <- "Not Available"
  }
  
}

clusterScore <- HospitalData[HospitalData$OverallRating != "Not Available",c("Provider_ID","OverallRating")]

#######################################################################################################
### Step 8 - K-Means Clustering to arrive at Five Star Rating
#######################################################################################################

set.seed(777)
clusterRating <- kmeans(clusterScore$OverallRating, 5, nstart = 100)
summary(factor(clusterRating$cluster))
clusterScore$cluster_Rating <- clusterRating$cluster
detach(package:plyr) #To be able to group by and summarize
clusterDataFinal <- group_by(clusterScore, cluster_Rating)
clusterDataFinal$OverallRating <- as.numeric(as.character(clusterDataFinal$OverallRating))
meanRating <- data.frame(summarise(clusterDataFinal,mean=mean(OverallRating)))
meanRating <- meanRating[order(meanRating$mean),]
meanRating$revisedRating <- c(1,2,3,4,5)

#Set rating based on proper order
clusterDataFinal <- sqldf("SELECT cd.Provider_ID, cd.OverallRating, mr.revisedRating as StarRating from clusterDataFinal cd, meanRating mr 
                          where cd.cluster_Rating = mr.cluster_Rating")

clusterDataFinal <- group_by(clusterDataFinal, StarRating)
summarise(clusterDataFinal,mean=mean(OverallRating),count=n()) #Now the Means & the Star Rating are rightly placed 

#######################################################################################################	
### Step 9 - Confusion Matrix with Unsupervised learning Model CMS Rating Vs 2016 CMS Rating
#######################################################################################################	

HospitalData <- merge( HospitalData,clusterDataFinal, by="Provider_ID", all=T)
HospitalData$StarRating[is.na(HospitalData$StarRating)]<-"Not Available"
names(CMSHospData)[1] <- "Provider_ID"
names(HospitalData)[1] <- "Provider_ID"
compareModelOutput <- HospitalData[,c("Provider_ID","StarRating")]
CMSHospData <- merge(CMSHospData,compareModelOutput, by="Provider_ID", all=T)
comparisonTable = table(CMSHospData$StarRating, CMSHospData$Hospital_overall_rating)
confusionMatrix(comparisonTable)
write.xlsx(CMSHospData, "C:/Masters/PGDDS/Capstone/Template/modelStarRating.xlsx")#Hospital Score
write.xlsx(HospitalData, "C:/Masters/PGDDS/Capstone/Template/modelGroupScore.xlsx")#Group Score

#######################################################################################################
#############################################End of Part 2#############################################
#######################################################################################################


#######################################################################################################
###############Part 1 - Supervised Learning-Based Rating###############################################
###############Create a random forest to predict the hospital ratings (1-5) using the 64 measures specified by the CMS. 
#######################################################################################################
###########Merging the data ####################################################

EMI_Wide1<-EMI_Wide
EMI_RF<-subset(EMI_Wide1,select=c(Provider_ID))
EMI_RF<-cbind(EMI_RF,EMI_Model_RF)

EOC_Wide1<-EOC_Wide
EOC_RF<-subset(EOC_Wide1,select=c(Provider_ID))
EOC_RF<-cbind(EOC_RF,EOC_Model_RF)

MOR_Wide1<-MOR_Wide
MOR_RF<-subset(MOR_Wide1,select=c(Provider_ID))
MOR_RF<-cbind(MOR_RF,MOR_Model_RF)

OIE_Wide1<-OIE_Wide
OIE_RF<-subset(OIE_Wide1,select=c(Provider_ID))
OIE_RF<-cbind(OIE_RF,OIE_Model_RF)

PEX_Wide1<-PEX_Wide
PEX_RF<-subset(PEX_Wide1,select=c(Provider_ID))
PEX_RF<-cbind(PEX_RF,PEX_Model_RF)

SOC_Wide1<-SOC_Wide
SOC_RF<-subset(SOC_Wide1,select=c(Provider_ID))
SOC_RF<-cbind(SOC_RF,SOC_Model_RF)

RAD_Wide1<-RAD_Wide
RAD_RF<-subset(RAD_Wide1,select=c(Provider_ID))
RAD_RF<-cbind(RAD_RF,RAD_Model_RF)


TOC_Wide1<-TOC_Wide
TOC_RF<-subset(TOC_Wide1,select=c(Provider_ID))
TOC_RF<-cbind(TOC_RF,TOC_Model_RF)

VOC_Wide1<-VOC_Wide
VOC_RF<-subset(VOC_Wide1,select=c(Provider_ID))
VOC_RF<-cbind(VOC_RF,VOC_Model_RF)

#Merging each measure file in wide format to one master file#

RF_master <- merge(EMI_RF,EOC_RF, by="Provider_ID",all=TRUE)
RF_master <- merge(RF_master,MOR_RF, by="Provider_ID",all=TRUE)
RF_master <- merge(RF_master,OIE_RF, by="Provider_ID",all=TRUE)
RF_master <- merge(RF_master,PEX_RF, by="Provider_ID",all=TRUE)
RF_master <- merge(RF_master,TOC_RF, by="Provider_ID",all=TRUE)
RF_master <- merge(RF_master,VOC_RF, by="Provider_ID",all=TRUE)
RF_master <- merge(RF_master,SOC_RF, by="Provider_ID",all=TRUE)
RF_master <- merge(RF_master,RAD_RF, by="Provider_ID",all=TRUE)

rm("TOC_Wide1","VOC_Wide1","RAD_Wide1","SOC_Wide1","PEX_Wide1","OIE_Wide1","EMI_Wide1","EOC_Wide1","MOR_Wide1")

str(RF_master) #4586 obs. of  65 variables
sapply(RF_master, function(x) sum(is.na(x)))

#Reading ratings from Hospital General Information file#

HospitalData_RF <- read.csv("Hospital General Information.csv",stringsAsFactors = TRUE,header=T, na.strings=c("","NA"))
Ratings_RF<-subset(HospitalData_RF ,select=c(Provider.ID , Hospital.overall.rating))
Ratings_RF[which(Ratings_RF$Hospital.overall.rating == "Not Available"), 2] <- NA
#Replacing NotAvailable with NA
names(Ratings_RF) <- gsub("\\.", "_", names(Ratings_RF))
summary(Ratings_RF)

# Merge RF_master with ratings information#

RF_master <- merge(RF_master,Ratings_RF, by="Provider_ID",all=TRUE)
str(RF_master)

#Remove rows with rating as NA as this can be ignored for supervised modelling
RF_master <- RF_master[-which(is.na(RF_master$Hospital_overall_rating)), ]
sapply(HospitalData_RF, function(x) sum(is.na(x)))

RF_master1<-RF_master

#rm(RF_master)

#Removing NA by 0 in RF_master#

RF_master[is.na(RF_master)]<-0
sapply(RF_master, function(x) sum(is.na(x)))
str(RF_master)

#######Outlier Correction for Supervised Model#############
#CHecking foroutliers and updating each variable to upperbound and lowerbound using IQR in merged data#

boxplot(RF_master$OP_10)
UB1<-quantile(RF_master$OP_10,0.75)+1.5*IQR(RF_master$OP_10)
UB1
length(RF_master$OP_10[RF_master$OP_10>UB1])###outliers
RF_master$OP_10[RF_master$OP_10>UB1]<-UB1
boxplot(RF_master$OP_10)


boxplot(RF_master$ OP_11 )
UB1<-quantile(RF_master$ OP_11 ,0.75)+1.5*IQR(RF_master$ OP_11 )
UB1
length(RF_master$ OP_11 [RF_master$ OP_11 >UB1])###outliers
RF_master$ OP_11 [RF_master$OP_11>UB1]<-UB1
boxplot(RF_master$ OP_11)


boxplot(RF_master$ OP_13  )
UB1<-quantile(RF_master$ OP_13  ,0.75)+1.5*IQR(RF_master$ OP_13  )
UB1
length(RF_master$ OP_13  [RF_master$ OP_13  >UB1])###outliers
RF_master$ OP_13  [RF_master$OP_13 >UB1]<-UB1
boxplot(RF_master$ OP_13 )


boxplot(RF_master$ OP_14  )
UB1<-quantile(RF_master$ OP_14  ,0.75)+1.5*IQR(RF_master$ OP_14  )
UB1
length(RF_master$ OP_14  [RF_master$ OP_14  >UB1])###outliers
RF_master$ OP_14  [RF_master$OP_14 >UB1]<-UB1
boxplot(RF_master$ OP_14 )


boxplot(RF_master$ OP_8   )
UB1<-quantile(RF_master$ OP_8   ,0.75)+1.5*IQR(RF_master$ OP_8   )
UB1
length(RF_master$ OP_8   [RF_master$ OP_8   >UB1])###outliers
RF_master$ OP_8   [RF_master$OP_8  >UB1]<-UB1
boxplot(RF_master$ OP_8  )
LB1<-quantile(RF_master$ OP_8,0.25)-1.5*IQR(RF_master$ OP_8   )
LB1
length(RF_master$ OP_8   [RF_master$ OP_8<LB1])###outliers
RF_master$ OP_8   [RF_master$OP_8<LB1]<-LB1
boxplot(RF_master$ OP_8   )


boxplot(RF_master$ OP_9   )
UB1<-quantile(RF_master$ OP_9   ,0.75)+1.5*IQR(RF_master$ OP_9   )
UB1
length(RF_master$ OP_9   [RF_master$ OP_9   >UB1])###outliers
RF_master$ OP_9   [RF_master$OP_9  >UB1]<-UB1
boxplot(RF_master$ OP_9  )

boxplot(RF_master$ EDV   )

boxplot(RF_master$ IMM_2   )
LB1<-quantile(RF_master$ IMM_2   ,0.25)-1.5*IQR(RF_master$ IMM_2   )
LB1
length(RF_master$ IMM_2   [RF_master$ IMM_2   <LB1])###outliers
RF_master$ IMM_2   [RF_master$IMM_2  <LB1]<-LB1
boxplot(RF_master$ IMM_2  )

boxplot(RF_master$ IMM_3_OP_27_FAC_ADHPCT    )
LB1<-quantile(RF_master$ IMM_3_OP_27_FAC_ADHPCT    ,0.25)-1.5*IQR(RF_master$ IMM_3_OP_27_FAC_ADHPCT    )
LB1
length(RF_master$ IMM_3_OP_27_FAC_ADHPCT    [RF_master$ IMM_3_OP_27_FAC_ADHPCT    <LB1])###outliers
RF_master$ IMM_3_OP_27_FAC_ADHPCT    [RF_master$IMM_3_OP_27_FAC_ADHPCT   <LB1]<-LB1
boxplot(RF_master$ IMM_3_OP_27_FAC_ADHPCT   )

boxplot(RF_master$ OP_22   )
UB1<-quantile(RF_master$  OP_22   ,0.75)+1.5*IQR(RF_master$  OP_22   )
UB1
length(RF_master$  OP_22   [RF_master$ OP_22   >UB1])###outliers
RF_master$ OP_22 [RF_master$ OP_22  >UB1]<-UB1
boxplot(RF_master$ OP_22  )


boxplot(RF_master$  OP_23   )
LB1<-quantile(RF_master$ OP_23   ,0.25)-1.5*IQR(RF_master$ OP_23   )
LB1
length(RF_master$ OP_23   [RF_master$ OP_23   <LB1])###outliers
RF_master$OP_23   [RF_master$OP_23  <LB1]<-LB1
boxplot(RF_master$  OP_23  )

boxplot(RF_master$ OP_29   )
LB1<-quantile(RF_master$ OP_29,0.25)-1.5*IQR(RF_master$ OP_29   )
LB1
length(RF_master$ OP_29   [RF_master$ OP_29<LB1])###outliers
RF_master$ OP_29   [RF_master$OP_29<LB1]<-LB1
boxplot(RF_master$ OP_29   )

boxplot(RF_master$ OP_30   )
LB1<-quantile(RF_master$ OP_30,0.25)-1.5*IQR(RF_master$ OP_30   )
LB1
length(RF_master$ OP_30   [RF_master$ OP_30<LB1])###outliers
RF_master$ OP_30   [RF_master$OP_30<LB1]<-LB1
boxplot(RF_master$ OP_30   )



boxplot(RF_master$   OP_4   )
LB1<-quantile(RF_master$   OP_4,0.25)-1.5*IQR(RF_master$   OP_4   )
LB1
length(RF_master$   OP_4   [RF_master$   OP_4<LB1])###outliers
RF_master$   OP_4   [RF_master$  OP_4<LB1]<-LB1
boxplot(RF_master$   OP_4   )

boxplot(RF_master$ PC_01   )
UB1<-quantile(RF_master$ PC_01   ,0.75)+1.5*IQR(RF_master$ PC_01   )
UB1
length(RF_master$ PC_01   [RF_master$ PC_01   >UB1])###outliers
RF_master$ PC_01   [RF_master$PC_01  >UB1]<-UB1
boxplot(RF_master$ PC_01  )

boxplot(RF_master$ VTE_6   )
UB1<-quantile(RF_master$ VTE_6   ,0.75)+1.5*IQR(RF_master$ VTE_6   )
UB1
length(RF_master$ VTE_6   [RF_master$ VTE_6   >UB1])###outliers
RF_master$ VTE_6   [RF_master$VTE_6  >UB1]<-UB1
boxplot(RF_master$ VTE_6  )


boxplot(RF_master$ MORT_30_AMI   )
UB1<-quantile(RF_master$ MORT_30_AMI   ,0.75)+1.5*IQR(RF_master$ MORT_30_AMI   )
UB1
length(RF_master$ MORT_30_AMI   [RF_master$ MORT_30_AMI   >UB1])###outliers
RF_master$ MORT_30_AMI   [RF_master$MORT_30_AMI  >UB1]<-UB1
boxplot(RF_master$ MORT_30_AMI  )
LB1<-quantile(RF_master$ MORT_30_AMI,0.25)-1.5*IQR(RF_master$ MORT_30_AMI   )
LB1
length(RF_master$ MORT_30_AMI   [RF_master$ MORT_30_AMI<LB1])###outliers
RF_master$ MORT_30_AMI   [RF_master$MORT_30_AMI<LB1]<-LB1
boxplot(RF_master$ MORT_30_AMI   )

boxplot(RF_master$ MORT_30_CABG    )
UB1<-quantile(RF_master$ MORT_30_CABG   ,0.75)+1.5*IQR(RF_master$ MORT_30_CABG    )
UB1
length(RF_master$ MORT_30_CABG    [RF_master$ MORT_30_CABG    >UB1])###outliers
RF_master$ MORT_30_CABG    [RF_master$MORT_30_CABG   >UB1]<-UB1
boxplot(RF_master$ MORT_30_CABG   )


boxplot(RF_master$  MORT_30_COPD   )
UB1<-quantile(RF_master$  MORT_30_COPD   ,0.75)+1.5*IQR(RF_master$  MORT_30_COPD   )
UB1
length(RF_master$  MORT_30_COPD   [RF_master$  MORT_30_COPD   >UB1])###outliers
RF_master$  MORT_30_COPD   [RF_master$ MORT_30_COPD  >UB1]<-UB1
boxplot(RF_master$  MORT_30_COPD  )
LB1<-quantile(RF_master$  MORT_30_COPD,0.25)-1.5*IQR(RF_master$  MORT_30_COPD   )
LB1
length(RF_master$  MORT_30_COPD   [RF_master$  MORT_30_COPD<LB1])###outliers
RF_master$  MORT_30_COPD   [RF_master$ MORT_30_COPD<LB1]<-LB1
boxplot(RF_master$  MORT_30_COPD   )

boxplot(RF_master$ MORT_30_HF    )
UB1<-quantile(RF_master$ MORT_30_HF    ,0.75)+1.5*IQR(RF_master$ MORT_30_HF    )
UB1
length(RF_master$ MORT_30_HF    [RF_master$ MORT_30_HF    >UB1])###outliers
RF_master$ MORT_30_HF    [RF_master$MORT_30_HF   >UB1]<-UB1
boxplot(RF_master$ MORT_30_HF   )
LB1<-quantile(RF_master$ MORT_30_HF ,0.25)-1.5*IQR(RF_master$ MORT_30_HF    )
LB1
length(RF_master$ MORT_30_HF    [RF_master$ MORT_30_HF <LB1])###outliers
RF_master$ MORT_30_HF    [RF_master$MORT_30_HF <LB1]<-LB1
boxplot(RF_master$ MORT_30_HF    )

boxplot(RF_master$ MORT_30_PN   )
UB1<-quantile(RF_master$ MORT_30_PN   ,0.75)+1.5*IQR(RF_master$ MORT_30_PN   )
UB1
length(RF_master$ MORT_30_PN   [RF_master$ MORT_30_PN   >UB1])###outliers
RF_master$ MORT_30_PN   [RF_master$MORT_30_PN  >UB1]<-UB1
boxplot(RF_master$ MORT_30_PN  )
LB1<-quantile(RF_master$ MORT_30_PN,0.25)-1.5*IQR(RF_master$ MORT_30_PN   )
LB1
length(RF_master$ MORT_30_PN   [RF_master$ MORT_30_PN<LB1])###outliers
RF_master$ MORT_30_PN   [RF_master$MORT_30_PN<LB1]<-LB1
boxplot(RF_master$ MORT_30_PN   )

boxplot(RF_master$ MORT_30_STK   )
UB1<-quantile(RF_master$ MORT_30_STK   ,0.75)+1.5*IQR(RF_master$ MORT_30_STK   )
UB1
length(RF_master$ MORT_30_STK   [RF_master$ MORT_30_STK   >UB1])###outliers
RF_master$ MORT_30_STK   [RF_master$MORT_30_STK  >UB1]<-UB1
boxplot(RF_master$ MORT_30_STK  )
LB1<-quantile(RF_master$ MORT_30_STK,0.25)-1.5*IQR(RF_master$ MORT_30_STK   )
LB1
length(RF_master$ MORT_30_STK   [RF_master$ MORT_30_STK<LB1])###outliers
RF_master$ MORT_30_STK   [RF_master$MORT_30_STK<LB1]<-LB1
boxplot(RF_master$ MORT_30_STK   )

boxplot(RF_master$ PSI_4_SURG_COMP   )
UB1<-quantile(RF_master$ PSI_4_SURG_COMP   ,0.75)+1.5*IQR(RF_master$ PSI_4_SURG_COMP   )
UB1
length(RF_master$ PSI_4_SURG_COMP   [RF_master$ PSI_4_SURG_COMP   >UB1])###outliers
RF_master$ PSI_4_SURG_COMP   [RF_master$PSI_4_SURG_COMP  >UB1]<-UB1
boxplot(RF_master$ PSI_4_SURG_COMP  )
LB1<-quantile(RF_master$ PSI_4_SURG_COMP,0.25)-1.5*IQR(RF_master$ PSI_4_SURG_COMP   )
LB1
length(RF_master$ PSI_4_SURG_COMP   [RF_master$ PSI_4_SURG_COMP<LB1])###outliers
RF_master$ PSI_4_SURG_COMP   [RF_master$PSI_4_SURG_COMP<LB1]<-LB1
boxplot(RF_master$ PSI_4_SURG_COMP   )


boxplot(RF_master$ OP_12    )
LB1<-quantile(RF_master$ OP_12 ,0.25)-1.5*IQR(RF_master$ OP_12    )
LB1
length(RF_master$ OP_12    [RF_master$ OP_12 <LB1])###outliers
RF_master$ OP_12    [RF_master$OP_12 <LB1]<-LB1
boxplot(RF_master$ OP_12    )

boxplot(RF_master$  OP_17   )
LB1<-quantile(RF_master$  OP_17,0.25)-1.5*IQR(RF_master$  OP_17   )
LB1
length(RF_master$  OP_17   [RF_master$  OP_17<LB1])###outliers
RF_master$  OP_17   [RF_master$ OP_17<LB1]<-LB1
boxplot(RF_master$  OP_17   )

boxplot(RF_master$ H_CLEAN_LINEAR_SCORE   )
LB1<-quantile(RF_master$ H_CLEAN_LINEAR_SCORE,0.25)-1.5*IQR(RF_master$ H_CLEAN_LINEAR_SCORE   )
LB1
length(RF_master$ H_CLEAN_LINEAR_SCORE   [RF_master$ H_CLEAN_LINEAR_SCORE<LB1])###outliers
RF_master$ H_CLEAN_LINEAR_SCORE   [RF_master$H_CLEAN_LINEAR_SCORE<LB1]<-LB1
boxplot(RF_master$ H_CLEAN_LINEAR_SCORE   )

boxplot(RF_master$ H_COMP_1_LINEAR_SCORE   )
UB1<-quantile(RF_master$ H_COMP_1_LINEAR_SCORE   ,0.75)+1.5*IQR(RF_master$ H_COMP_1_LINEAR_SCORE   )
UB1
length(RF_master$ H_COMP_1_LINEAR_SCORE   [RF_master$ H_COMP_1_LINEAR_SCORE   >UB1])###outliers
RF_master$ H_COMP_1_LINEAR_SCORE   [RF_master$H_COMP_1_LINEAR_SCORE  >UB1]<-UB1
boxplot(RF_master$ H_COMP_1_LINEAR_SCORE  )
LB1<-quantile(RF_master$ H_COMP_1_LINEAR_SCORE,0.25)-1.5*IQR(RF_master$ H_COMP_1_LINEAR_SCORE   )
LB1
length(RF_master$ H_COMP_1_LINEAR_SCORE   [RF_master$ H_COMP_1_LINEAR_SCORE<LB1])###outliers
RF_master$ H_COMP_1_LINEAR_SCORE   [RF_master$H_COMP_1_LINEAR_SCORE<LB1]<-LB1
boxplot(RF_master$ H_COMP_1_LINEAR_SCORE   )


boxplot(RF_master$ H_COMP_2_LINEAR_SCORE   )
UB1<-quantile(RF_master$ H_COMP_2_LINEAR_SCORE   ,0.75)+1.5*IQR(RF_master$ H_COMP_2_LINEAR_SCORE   )
UB1
length(RF_master$ H_COMP_2_LINEAR_SCORE   [RF_master$ H_COMP_2_LINEAR_SCORE   >UB1])###outliers
RF_master$ H_COMP_2_LINEAR_SCORE   [RF_master$H_COMP_2_LINEAR_SCORE  >UB1]<-UB1
boxplot(RF_master$ H_COMP_2_LINEAR_SCORE  )
LB1<-quantile(RF_master$ H_COMP_2_LINEAR_SCORE,0.25)-1.5*IQR(RF_master$ H_COMP_2_LINEAR_SCORE   )
LB1
length(RF_master$ H_COMP_2_LINEAR_SCORE   [RF_master$ H_COMP_2_LINEAR_SCORE<LB1])###outliers
RF_master$ H_COMP_2_LINEAR_SCORE   [RF_master$H_COMP_2_LINEAR_SCORE<LB1]<-LB1
boxplot(RF_master$ H_COMP_2_LINEAR_SCORE   )

boxplot(RF_master$ H_COMP_4_LINEAR_SCORE   )
UB1<-quantile(RF_master$ H_COMP_4_LINEAR_SCORE   ,0.75)+1.5*IQR(RF_master$ H_COMP_4_LINEAR_SCORE   )
UB1
length(RF_master$ H_COMP_4_LINEAR_SCORE   [RF_master$ H_COMP_4_LINEAR_SCORE   >UB1])###outliers
RF_master$ H_COMP_4_LINEAR_SCORE   [RF_master$H_COMP_4_LINEAR_SCORE  >UB1]<-UB1
boxplot(RF_master$ H_COMP_4_LINEAR_SCORE  )
LB1<-quantile(RF_master$ H_COMP_4_LINEAR_SCORE,0.25)-1.5*IQR(RF_master$ H_COMP_4_LINEAR_SCORE   )
LB1
length(RF_master$ H_COMP_4_LINEAR_SCORE   [RF_master$ H_COMP_4_LINEAR_SCORE<LB1])###outliers
RF_master$ H_COMP_4_LINEAR_SCORE   [RF_master$H_COMP_4_LINEAR_SCORE<LB1]<-LB1
boxplot(RF_master$ H_COMP_4_LINEAR_SCORE   )

boxplot(RF_master$ H_COMP_5_LINEAR_SCORE    )
UB1<-quantile(RF_master$ H_COMP_5_LINEAR_SCORE    ,0.75)+1.5*IQR(RF_master$ H_COMP_5_LINEAR_SCORE    )
UB1
length(RF_master$ H_COMP_5_LINEAR_SCORE    [RF_master$ H_COMP_5_LINEAR_SCORE    >UB1])###outliers
RF_master$ H_COMP_5_LINEAR_SCORE    [RF_master$H_COMP_5_LINEAR_SCORE   >UB1]<-UB1
boxplot(RF_master$ H_COMP_5_LINEAR_SCORE   )
LB1<-quantile(RF_master$ H_COMP_5_LINEAR_SCORE ,0.25)-1.5*IQR(RF_master$ H_COMP_5_LINEAR_SCORE    )
LB1
length(RF_master$ H_COMP_5_LINEAR_SCORE    [RF_master$ H_COMP_5_LINEAR_SCORE <LB1])###outliers
RF_master$ H_COMP_5_LINEAR_SCORE    [RF_master$H_COMP_5_LINEAR_SCORE <LB1]<-LB1
boxplot(RF_master$ H_COMP_5_LINEAR_SCORE    )

boxplot(RF_master$ H_COMP_6_LINEAR_SCORE   )
UB1<-quantile(RF_master$ H_COMP_6_LINEAR_SCORE   ,0.75)+1.5*IQR(RF_master$ H_COMP_6_LINEAR_SCORE   )
UB1
length(RF_master$ H_COMP_6_LINEAR_SCORE   [RF_master$ H_COMP_6_LINEAR_SCORE   >UB1])###outliers
RF_master$ H_COMP_6_LINEAR_SCORE   [RF_master$H_COMP_6_LINEAR_SCORE  >UB1]<-UB1
boxplot(RF_master$ H_COMP_6_LINEAR_SCORE  )
LB1<-quantile(RF_master$ H_COMP_6_LINEAR_SCORE,0.25)-1.5*IQR(RF_master$ H_COMP_6_LINEAR_SCORE   )
LB1
length(RF_master$ H_COMP_6_LINEAR_SCORE   [RF_master$ H_COMP_6_LINEAR_SCORE<LB1])###outliers
RF_master$ H_COMP_6_LINEAR_SCORE   [RF_master$H_COMP_6_LINEAR_SCORE<LB1]<-LB1
boxplot(RF_master$ H_COMP_6_LINEAR_SCORE   )

boxplot(RF_master$ H_COMP_7_LINEAR_SCORE   )
UB1<-quantile(RF_master$ H_COMP_7_LINEAR_SCORE   ,0.75)+1.5*IQR(RF_master$ H_COMP_7_LINEAR_SCORE   )
UB1
length(RF_master$ H_COMP_7_LINEAR_SCORE   [RF_master$ H_COMP_7_LINEAR_SCORE   >UB1])###outliers
RF_master$ H_COMP_7_LINEAR_SCORE   [RF_master$H_COMP_7_LINEAR_SCORE  >UB1]<-UB1
boxplot(RF_master$ H_COMP_7_LINEAR_SCORE  )
LB1<-quantile(RF_master$ H_COMP_7_LINEAR_SCORE,0.25)-1.5*IQR(RF_master$ H_COMP_7_LINEAR_SCORE   )
LB1
length(RF_master$ H_COMP_7_LINEAR_SCORE   [RF_master$ H_COMP_7_LINEAR_SCORE<LB1])###outliers
RF_master$ H_COMP_7_LINEAR_SCORE   [RF_master$H_COMP_7_LINEAR_SCORE<LB1]<-LB1
boxplot(RF_master$ H_COMP_7_LINEAR_SCORE   )

boxplot(RF_master$ H_HSP_RATING_LINEAR_SCORE   )
UB1<-quantile(RF_master$ H_HSP_RATING_LINEAR_SCORE   ,0.75)+1.5*IQR(RF_master$ H_HSP_RATING_LINEAR_SCORE   )
UB1
length(RF_master$ H_HSP_RATING_LINEAR_SCORE   [RF_master$ H_HSP_RATING_LINEAR_SCORE   >UB1])###outliers
RF_master$ H_HSP_RATING_LINEAR_SCORE   [RF_master$H_HSP_RATING_LINEAR_SCORE  >UB1]<-UB1
boxplot(RF_master$ H_HSP_RATING_LINEAR_SCORE  )
LB1<-quantile(RF_master$ H_HSP_RATING_LINEAR_SCORE,0.25)-1.5*IQR(RF_master$ H_HSP_RATING_LINEAR_SCORE   )
LB1
length(RF_master$ H_HSP_RATING_LINEAR_SCORE   [RF_master$ H_HSP_RATING_LINEAR_SCORE<LB1])###outliers
RF_master$ H_HSP_RATING_LINEAR_SCORE   [RF_master$H_HSP_RATING_LINEAR_SCORE<LB1]<-LB1
boxplot(RF_master$ H_HSP_RATING_LINEAR_SCORE   )

boxplot(RF_master$  H_RECMND_LINEAR_SCORE   )
LB1<-quantile(RF_master$  H_RECMND_LINEAR_SCORE,0.25)-1.5*IQR(RF_master$  H_RECMND_LINEAR_SCORE   )
LB1
length(RF_master$  H_RECMND_LINEAR_SCORE   [RF_master$  H_RECMND_LINEAR_SCORE<LB1])###outliers
RF_master$  H_RECMND_LINEAR_SCORE   [RF_master$ H_RECMND_LINEAR_SCORE<LB1]<-LB1
boxplot(RF_master$  H_RECMND_LINEAR_SCORE   )

boxplot(RF_master$ H_QUIET_LINEAR_SCORE   )
LB1<-quantile(RF_master$ H_QUIET_LINEAR_SCORE,0.25)-1.5*IQR(RF_master$ H_QUIET_LINEAR_SCORE   )
LB1
length(RF_master$ H_QUIET_LINEAR_SCORE   [RF_master$ H_QUIET_LINEAR_SCORE<LB1])###outliers
RF_master$ H_QUIET_LINEAR_SCORE   [RF_master$H_QUIET_LINEAR_SCORE<LB1]<-LB1
boxplot(RF_master$ H_QUIET_LINEAR_SCORE   )

boxplot(RF_master$ ED_1b    )
UB1<-quantile(RF_master$ ED_1b    ,0.75)+1.5*IQR(RF_master$ ED_1b    )
UB1
length(RF_master$ ED_1b    [RF_master$ ED_1b    >UB1])###outliers
RF_master$ ED_1b    [RF_master$ED_1b   >UB1]<-UB1
boxplot(RF_master$ ED_1b   )
LB1<-quantile(RF_master$ ED_1b ,0.25)-1.5*IQR(RF_master$ ED_1b    )
LB1
length(RF_master$ ED_1b    [RF_master$ ED_1b <LB1])###outliers
RF_master$ ED_1b    [RF_master$ED_1b <LB1]<-LB1
boxplot(RF_master$ ED_1b    )

boxplot(RF_master$  ED_2b   )
UB1<-quantile(RF_master$  ED_2b   ,0.75)+1.5*IQR(RF_master$  ED_2b   )
UB1
length(RF_master$  ED_2b   [RF_master$  ED_2b   >UB1])###outliers
RF_master$  ED_2b   [RF_master$ ED_2b  >UB1]<-UB1
boxplot(RF_master$  ED_2b  )

boxplot(RF_master$  OP_18b   )
UB1<-quantile(RF_master$  OP_18b   ,0.75)+1.5*IQR(RF_master$  OP_18b   )
UB1
length(RF_master$  OP_18b   [RF_master$  OP_18b   >UB1])###outliers
RF_master$  OP_18b   [RF_master$ OP_18b  >UB1]<-UB1
boxplot(RF_master$  OP_18b  )
LB1<-quantile(RF_master$  OP_18b,0.25)-1.5*IQR(RF_master$  OP_18b   )
LB1
length(RF_master$  OP_18b   [RF_master$  OP_18b<LB1])###outliers
RF_master$  OP_18b   [RF_master$ OP_18b<LB1]<-LB1
boxplot(RF_master$  OP_18b   )


boxplot(RF_master$ OP_20   )
UB1<-quantile(RF_master$ OP_20   ,0.75)+1.5*IQR(RF_master$ OP_20   )
UB1
length(RF_master$ OP_20   [RF_master$ OP_20   >UB1])###outliers
RF_master$ OP_20   [RF_master$OP_20  >UB1]<-UB1
boxplot(RF_master$ OP_20  )

boxplot(RF_master$ OP_21   )
UB1<-quantile(RF_master$ OP_21   ,0.75)+1.5*IQR(RF_master$ OP_21   )
UB1
length(RF_master$ OP_21   [RF_master$ OP_21   >UB1])###outliers
RF_master$ OP_21   [RF_master$OP_21  >UB1]<-UB1
boxplot(RF_master$ OP_21  )

boxplot(RF_master$ OP_25   )
LB1<-quantile(RF_master$ OP_25,0.25)-1.5*IQR(RF_master$ OP_25   )
LB1
length(RF_master$ OP_25   [RF_master$ OP_25<LB1])###outliers
RF_master$ OP_25   [RF_master$OP_25<LB1]<-LB1
boxplot(RF_master$ OP_25   )

boxplot(RF_master$ SM_SS_CHECK   )
LB1<-quantile(RF_master$ SM_SS_CHECK,0.25)-1.5*IQR(RF_master$ SM_SS_CHECK   )
LB1
length(RF_master$ SM_SS_CHECK   [RF_master$ SM_SS_CHECK<LB1])###outliers
RF_master$ SM_SS_CHECK   [RF_master$SM_SS_CHECK<LB1]<-LB1
boxplot(RF_master$ SM_SS_CHECK   )

boxplot(RF_master$ OP_5   )
UB1<-quantile(RF_master$ OP_5   ,0.75)+1.5*IQR(RF_master$ OP_5   )
UB1
length(RF_master$ OP_5   [RF_master$ OP_5   >UB1])###outliers
RF_master$ OP_5   [RF_master$OP_5  >UB1]<-UB1
boxplot(RF_master$ OP_5  )

boxplot(RF_master$ MSPB_1   )
UB1<-quantile(RF_master$ MSPB_1   ,0.75)+1.5*IQR(RF_master$ MSPB_1   )
UB1
length(RF_master$ MSPB_1   [RF_master$ MSPB_1   >UB1])###outliers
RF_master$ MSPB_1   [RF_master$MSPB_1  >UB1]<-UB1
boxplot(RF_master$ MSPB_1  )
LB1<-quantile(RF_master$ MSPB_1,0.25)-1.5*IQR(RF_master$ MSPB_1   )
LB1
length(RF_master$ MSPB_1   [RF_master$ MSPB_1<LB1])###outliers
RF_master$ MSPB_1   [RF_master$MSPB_1<LB1]<-LB1
boxplot(RF_master$  MSPB_1   )

boxplot(RF_master$ COMP_HIP_KNEE   )
UB1<-quantile(RF_master$ COMP_HIP_KNEE   ,0.75)+1.5*IQR(RF_master$ COMP_HIP_KNEE   )
UB1
length(RF_master$ COMP_HIP_KNEE   [RF_master$ COMP_HIP_KNEE   >UB1])###outliers
RF_master$ COMP_HIP_KNEE   [RF_master$COMP_HIP_KNEE  >UB1]<-UB1
boxplot(RF_master$ COMP_HIP_KNEE  )
LB1<-quantile(RF_master$ COMP_HIP_KNEE,0.25)-1.5*IQR(RF_master$ COMP_HIP_KNEE   )
LB1
length(RF_master$ COMP_HIP_KNEE   [RF_master$ COMP_HIP_KNEE<LB1])###outliers
RF_master$ COMP_HIP_KNEE   [RF_master$COMP_HIP_KNEE<LB1]<-LB1
boxplot(RF_master$ COMP_HIP_KNEE   )

boxplot(RF_master$ HAI_1_SIR   )
UB1<-quantile(RF_master$ HAI_1_SIR   ,0.75)+1.5*IQR(RF_master$ HAI_1_SIR   )
UB1
length(RF_master$ HAI_1_SIR   [RF_master$ HAI_1_SIR   >UB1])###outliers
RF_master$ HAI_1_SIR   [RF_master$HAI_1_SIR  >UB1]<-UB1
boxplot(RF_master$ HAI_1_SIR  )

boxplot(RF_master$ HAI_2_SIR   )
UB1<-quantile(RF_master$ HAI_2_SIR   ,0.75)+1.5*IQR(RF_master$ HAI_2_SIR   )
UB1
length(RF_master$ HAI_2_SIR   [RF_master$ HAI_2_SIR   >UB1])###outliers
RF_master$ HAI_2_SIR   [RF_master$HAI_2_SIR  >UB1]<-UB1
boxplot(RF_master$ HAI_2_SIR  )

boxplot(RF_master$  HAI_3_SIR   )
UB1<-quantile(RF_master$  HAI_3_SIR   ,0.75)+1.5*IQR(RF_master$  HAI_3_SIR   )
UB1
length(RF_master$  HAI_3_SIR   [RF_master$  HAI_3_SIR   >UB1])###outliers
RF_master$  HAI_3_SIR   [RF_master$ HAI_3_SIR  >UB1]<-UB1
boxplot(RF_master$  HAI_3_SIR   )

boxplot(RF_master$ HAI_4_SIR   )
UB1<-quantile(RF_master$ HAI_4_SIR   ,0.75)+1.5*IQR(RF_master$ HAI_4_SIR   )
UB1
length(RF_master$ HAI_4_SIR   [RF_master$ HAI_4_SIR   >UB1])###outliers
RF_master$ HAI_4_SIR   [RF_master$HAI_4_SIR  >UB1]<-UB1
boxplot(RF_master$ HAI_4_SIR  )

boxplot(RF_master$ HAI_5_SIR   )
UB1<-quantile(RF_master$ HAI_5_SIR   ,0.75)+1.5*IQR(RF_master$ HAI_5_SIR   )
UB1
length(RF_master$ HAI_5_SIR   [RF_master$ HAI_5_SIR   >UB1])###outliers
RF_master$ HAI_5_SIR   [RF_master$HAI_5_SIR  >UB1]<-UB1
boxplot(RF_master$ HAI_5_SIR  )

boxplot(RF_master$ HAI_6_SIR   )
UB1<-quantile(RF_master$ HAI_6_SIR   ,0.75)+1.5*IQR(RF_master$ HAI_6_SIR   )
UB1
length(RF_master$ HAI_6_SIR   [RF_master$ HAI_6_SIR   >UB1])###outliers
RF_master$ HAI_6_SIR   [RF_master$HAI_6_SIR  >UB1]<-UB1
boxplot(RF_master$ HAI_6_SIR  )

boxplot(RF_master$ PSI_13_POST_SEPSIS   )
UB1<-quantile(RF_master$ PSI_13_POST_SEPSIS   ,0.75)+1.5*IQR(RF_master$ PSI_13_POST_SEPSIS   )
UB1
length(RF_master$ PSI_13_POST_SEPSIS   [RF_master$ PSI_13_POST_SEPSIS   >UB1])###outliers
RF_master$ PSI_13_POST_SEPSIS   [RF_master$PSI_13_POST_SEPSIS  >UB1]<-UB1
boxplot(RF_master$ PSI_13_POST_SEPSIS  )
LB1<-quantile(RF_master$ PSI_13_POST_SEPSIS,0.25)-1.5*IQR(RF_master$ PSI_13_POST_SEPSIS   )
LB1
length(RF_master$ PSI_13_POST_SEPSIS   [RF_master$ PSI_13_POST_SEPSIS<LB1])###outliers
RF_master$ PSI_13_POST_SEPSIS   [RF_master$PSI_13_POST_SEPSIS<LB1]<-LB1
boxplot(RF_master$ PSI_13_POST_SEPSIS   )

boxplot(RF_master$ PSI_3_ULCER   )
UB1<-quantile(RF_master$ PSI_3_ULCER   ,0.75)+1.5*IQR(RF_master$ PSI_3_ULCER   )
UB1
length(RF_master$ PSI_3_ULCER   [RF_master$ PSI_3_ULCER   >UB1])###outliers
RF_master$ PSI_3_ULCER   [RF_master$PSI_3_ULCER  >UB1]<-UB1
boxplot(RF_master$ PSI_3_ULCER  )

boxplot(RF_master$  PSI_6_IAT_PTX   )
UB1<-quantile(RF_master$  PSI_6_IAT_PTX   ,0.75)+1.5*IQR(RF_master$  PSI_6_IAT_PTX   )
UB1
length(RF_master$  PSI_6_IAT_PTX   [RF_master$  PSI_6_IAT_PTX   >UB1])###outliers
RF_master$  PSI_6_IAT_PTX   [RF_master$ PSI_6_IAT_PTX  >UB1]<-UB1
boxplot(RF_master$  PSI_6_IAT_PTX  )
LB1<-quantile(RF_master$  PSI_6_IAT_PTX,0.25)-1.5*IQR(RF_master$  PSI_6_IAT_PTX   )
LB1
length(RF_master$  PSI_6_IAT_PTX   [RF_master$  PSI_6_IAT_PTX<LB1])###outliers
RF_master$  PSI_6_IAT_PTX   [RF_master$ PSI_6_IAT_PTX<LB1]<-LB1
boxplot(RF_master$  PSI_6_IAT_PTX   )


boxplot(RF_master$ PSI_8_POST_HIP    )
LB1<-quantile(RF_master$ PSI_8_POST_HIP ,0.25)-1.5*IQR(RF_master$ PSI_8_POST_HIP    )
LB1
length(RF_master$ PSI_8_POST_HIP    [RF_master$ PSI_8_POST_HIP <LB1])###outliers
RF_master$ PSI_8_POST_HIP    [RF_master$PSI_8_POST_HIP <LB1]<-LB1
boxplot(RF_master$ PSI_8_POST_HIP    )

boxplot(RF_master$  PSI_90_SAFETY    )
UB1<-quantile(RF_master$  PSI_90_SAFETY    ,0.75)+1.5*IQR(RF_master$  PSI_90_SAFETY    )
UB1
length(RF_master$  PSI_90_SAFETY    [RF_master$  PSI_90_SAFETY    >UB1])###outliers
RF_master$  PSI_90_SAFETY    [RF_master$ PSI_90_SAFETY   >UB1]<-UB1
boxplot(RF_master$  PSI_90_SAFETY   )
LB1<-quantile(RF_master$  PSI_90_SAFETY ,0.25)-1.5*IQR(RF_master$  PSI_90_SAFETY    )
LB1
length(RF_master$  PSI_90_SAFETY    [RF_master$  PSI_90_SAFETY <LB1])###outliers
RF_master$  PSI_90_SAFETY    [RF_master$ PSI_90_SAFETY <LB1]<-LB1
boxplot(RF_master$  PSI_90_SAFETY    )

boxplot(RF_master$ READM_30_AMI    )
UB1<-quantile(RF_master$ READM_30_AMI    ,0.75)+1.5*IQR(RF_master$ READM_30_AMI    )
UB1
length(RF_master$ READM_30_AMI    [RF_master$ READM_30_AMI    >UB1])###outliers
RF_master$ READM_30_AMI    [RF_master$READM_30_AMI   >UB1]<-UB1
boxplot(RF_master$ READM_30_AMI   )
LB1<-quantile(RF_master$ READM_30_AMI ,0.25)-1.5*IQR(RF_master$ READM_30_AMI    )
LB1
length(RF_master$ READM_30_AMI    [RF_master$ READM_30_AMI <LB1])###outliers
RF_master$ READM_30_AMI    [RF_master$READM_30_AMI <LB1]<-LB1
boxplot(RF_master$ READM_30_AMI    )

boxplot(RF_master$ READM_30_CABG    )
UB1<-quantile(RF_master$ READM_30_CABG    ,0.75)+1.5*IQR(RF_master$ READM_30_CABG    )
UB1
length(RF_master$ READM_30_CABG    [RF_master$ READM_30_CABG    >UB1])###outliers
RF_master$ READM_30_CABG    [RF_master$READM_30_CABG   >UB1]<-UB1
boxplot(RF_master$ READM_30_CABG   )
LB1<-quantile(RF_master$ READM_30_CABG ,0.25)-1.5*IQR(RF_master$ READM_30_CABG    )
LB1
length(RF_master$ READM_30_CABG    [RF_master$ READM_30_CABG <LB1])###outliers
RF_master$ READM_30_CABG    [RF_master$READM_30_CABG <LB1]<-LB1
boxplot(RF_master$ READM_30_CABG    )

boxplot(RF_master$ READM_30_COPD    )
UB1<-quantile(RF_master$ READM_30_COPD    ,0.75)+1.5*IQR(RF_master$ READM_30_COPD    )
UB1
length(RF_master$ READM_30_COPD    [RF_master$ READM_30_COPD    >UB1])###outliers
RF_master$ READM_30_COPD    [RF_master$READM_30_COPD   >UB1]<-UB1
boxplot(RF_master$ READM_30_COPD   )
LB1<-quantile(RF_master$ READM_30_COPD ,0.25)-1.5*IQR(RF_master$ READM_30_COPD    )
LB1
length(RF_master$ READM_30_COPD    [RF_master$ READM_30_COPD <LB1])###outliers
RF_master$ READM_30_COPD    [RF_master$READM_30_COPD <LB1]<-LB1
boxplot(RF_master$ READM_30_COPD    )

boxplot(RF_master$ READM_30_HF    )
UB1<-quantile(RF_master$ READM_30_HF    ,0.75)+1.5*IQR(RF_master$ READM_30_HF    )
UB1
length(RF_master$ READM_30_HF    [RF_master$ READM_30_HF    >UB1])###outliers
RF_master$ READM_30_HF    [RF_master$READM_30_HF   >UB1]<-UB1
boxplot(RF_master$ READM_30_HF   )
LB1<-quantile(RF_master$ READM_30_HF ,0.25)-1.5*IQR(RF_master$ READM_30_HF    )
LB1
length(RF_master$ READM_30_HF    [RF_master$ READM_30_HF <LB1])###outliers
RF_master$ READM_30_HF    [RF_master$READM_30_HF <LB1]<-LB1
boxplot(RF_master$ READM_30_HF    )

boxplot(RF_master$ READM_30_HIP_KNEE    )
UB1<-quantile(RF_master$ READM_30_HIP_KNEE    ,0.75)+1.5*IQR(RF_master$ READM_30_HIP_KNEE    )
UB1
length(RF_master$ READM_30_HIP_KNEE    [RF_master$ READM_30_HIP_KNEE    >UB1])###outliers
RF_master$ READM_30_HIP_KNEE    [RF_master$READM_30_HIP_KNEE   >UB1]<-UB1
boxplot(RF_master$ READM_30_HIP_KNEE   )
LB1<-quantile(RF_master$ READM_30_HIP_KNEE ,0.25)-1.5*IQR(RF_master$ READM_30_HIP_KNEE    )
LB1
length(RF_master$ READM_30_HIP_KNEE    [RF_master$ READM_30_HIP_KNEE <LB1])###outliers
RF_master$ READM_30_HIP_KNEE    [RF_master$READM_30_HIP_KNEE <LB1]<-LB1
boxplot(RF_master$ READM_30_HIP_KNEE    )

boxplot(RF_master$ READM_30_HOSP_WIDE    )
UB1<-quantile(RF_master$ READM_30_HOSP_WIDE    ,0.75)+1.5*IQR(RF_master$ READM_30_HOSP_WIDE    )
UB1
length(RF_master$ READM_30_HOSP_WIDE    [RF_master$ READM_30_HOSP_WIDE    >UB1])###outliers
RF_master$ READM_30_HOSP_WIDE    [RF_master$READM_30_HOSP_WIDE   >UB1]<-UB1
boxplot(RF_master$ READM_30_HOSP_WIDE   )
LB1<-quantile(RF_master$ READM_30_HOSP_WIDE ,0.25)-1.5*IQR(RF_master$ READM_30_HOSP_WIDE    )
LB1
length(RF_master$ READM_30_HOSP_WIDE    [RF_master$ READM_30_HOSP_WIDE <LB1])###outliers
RF_master$ READM_30_HOSP_WIDE    [RF_master$READM_30_HOSP_WIDE <LB1]<-LB1
boxplot(RF_master$ READM_30_HOSP_WIDE    )

boxplot(RF_master$ READM_30_PN     )
UB1<-quantile(RF_master$ READM_30_PN     ,0.75)+1.5*IQR(RF_master$ READM_30_PN     )
UB1
length(RF_master$ READM_30_PN     [RF_master$ READM_30_PN     >UB1])###outliers
RF_master$ READM_30_PN     [RF_master$READM_30_PN    >UB1]<-UB1
boxplot(RF_master$ READM_30_PN    )
LB1<-quantile(RF_master$ READM_30_PN  ,0.25)-1.5*IQR(RF_master$ READM_30_PN     )
LB1
length(RF_master$ READM_30_PN     [RF_master$ READM_30_PN  <LB1])###outliers
RF_master$ READM_30_PN     [RF_master$READM_30_PN  <LB1]<-LB1
boxplot(RF_master$ READM_30_PN     )

boxplot(RF_master$ READM_30_STK    )
UB1<-quantile(RF_master$ READM_30_STK    ,0.75)+1.5*IQR(RF_master$ READM_30_STK    )
UB1
length(RF_master$ READM_30_STK    [RF_master$ READM_30_STK    >UB1])###outliers
RF_master$ READM_30_STK    [RF_master$READM_30_STK   >UB1]<-UB1
boxplot(RF_master$ READM_30_STK   )
LB1<-quantile(RF_master$ READM_30_STK ,0.25)-1.5*IQR(RF_master$ READM_30_STK    )
LB1
length(RF_master$ READM_30_STK    [RF_master$ READM_30_STK <LB1])###outliers
RF_master$ READM_30_STK    [RF_master$READM_30_STK <LB1]<-LB1
boxplot(RF_master$ READM_30_STK    )

#------------------------End of Outlier correction for RF modelling------------------#

RF_masterM<-RF_master

#####Data is ready for RF modelling#########
RF_master[,1]<-NULL
#Removing ProviderID from dataset
str(RF_master)

###############RF Modelling####################

# Shuffle the data
shuffledata <- RF_master[sample(nrow(RF_master)), ]
shuffledata$Hospital_overall_rating=as.factor(as.integer(shuffledata$Hospital_overall_rating))

# Split the data into train and test

ntrain <- as.integer(nrow(shuffledata)*0.8)
traindata <- shuffledata[1:ntrain, ]
testdata <- shuffledata[(ntrain+1):nrow(shuffledata), ]

# Build the random forest
set.seed(100)
#Starting with mtry with sqrt of number of predictor variables and ntree=500

data.rf0 <- randomForest(Hospital_overall_rating ~., data=traindata, mtry=8, na.action=na.omit, ntree=500)
data.rf0
d0 = data.frame(data.rf0$importance)
view(d0)
testPred0 <- predict(data.rf0, newdata=testdata)
table(testPred0, testdata$Hospital_overall_rating)
confusionMatrix(testPred0, testdata$Hospital_overall_rating)

#Increasing mtry=10 and ntree=800

data.rf01 <- randomForest(Hospital_overall_rating ~., data=traindata, mtry=10, na.action=na.omit, ntree=800)
data.rf01
d01 = data.frame(data.rf01$importance)
view(d01)
testPred01 <- predict(data.rf01, newdata=testdata)
table(testPred01, testdata$Hospital_overall_rating)
confusionMatrix(testPred01, testdata$Hospital_overall_rating)

#Increasing mtry=15 and ntree=800

data.rf02 <- randomForest(Hospital_overall_rating ~., data=traindata, mtry=15, na.action=na.omit, ntree=800)
data.rf02
d02 = data.frame(data.rf02$importance)
view(d02)
testPred02 <- predict(data.rf02, newdata=testdata)
table(testPred02, testdata$Hospital_overall_rating)
confusionMatrix(testPred02, testdata$Hospital_overall_rating)

#Increasing mtry=20 and ntree=800

data.rf <- randomForest(Hospital_overall_rating ~., data=traindata, mtry=20, na.action=na.omit, ntree=800)
data.rf
d = data.frame(data.rf$importance)
d
View(d)
testPred <- predict(data.rf, newdata=testdata)
table(testPred, testdata$Hospital_overall_rating)
confusionMatrix(testPred, testdata$Hospital_overall_rating)

#Keeping mtry=20 and increasing ntree=1000

data.rf11 <- randomForest(Hospital_overall_rating ~., data=traindata, mtry=20, na.action=na.omit, ntree=1000)
data.rf11
d11 = data.frame(data.rf11$importance)
d11
View(d11)
testPred11 <- predict(data.rf11, newdata=testdata)
table(testPred11, testdata$Hospital_overall_rating)
confusionMatrix(testPred11, testdata$Hospital_overall_rating)

#Keeping mtry=20 and increasing ntree=1200

data.rf1 <- randomForest(Hospital_overall_rating ~., data=traindata, mtry=20, na.action=na.omit, ntree=1200)
data.rf1
d1 = data.frame(data.rf1$importance)
d1
View(d1)
testPred1 <- predict(data.rf1, newdata=testdata)
table(testPred1, testdata$Hospital_overall_rating)
confusionMatrix(testPred1, testdata$Hospital_overall_rating)

#Keeping mtry=20 and increasing ntree=1400
data.rf2 <- randomForest(Hospital_overall_rating ~., data=traindata, mtry=20, na.action=na.omit, ntree=1400)
data.rf2
d2 = data.frame(data.rf1$importance)
d2
View(d2)
testPred2 <- predict(data.rf2, newdata=testdata)
table(testPred2, testdata$Hospital_overall_rating)
confusionMatrix(testPred2, testdata$Hospital_overall_rating)

#####################################################################################################

#Number of trees at 1200 and mtry=20 is giving better model in terms of prediction
#Final Model Selected for the supervised learning

data.rff <- randomForest(Hospital_overall_rating ~., data=traindata, mtry=20, na.action=na.omit, ntree=1200)
data.rff
d1f = data.frame(data.rff$importance)
d1f
View(d1f)
write.csv(d1f,"Importance.csv")
RF_Importancefinal <- d1f
testPred1f <- predict(data.rff, newdata=testdata)
table(testPred1f, testdata$Hospital_overall_rating)
confusionMatrix(testPred1f, testdata$Hospital_overall_rating)

#Choose that as the final model
#Class1 prediction metrics are not so great in any of RF model
#Class3 and Class4 are better


#######################################################################################################
###############End of Part 1 - Random Forest###########################################################
#######################################################################################################




#######################################################################################################
###############Part 3 - Recommendations for Hospitals#######################################
#### Objective:: The hospital's current star rating is 3 and it wants to improve it to at least 4 next year.
#### Highlight the low scoring measures and provideRecommendations
#######################################################################################################

# Chacking the details for "EVANSTON" hospital from national index file

EVANSTON <- HGI[ which(HGI$Provider.ID== 140010) , ]
colnames( EVANSTON) # EVANSTON overall rating is 3.

# Subset of "Acute Care hospitals"
Acute_hosp<-HGI[ which(HGI$Hospital.Type== "Acute Care Hospitals") , ]
nrow(Acute_hosp)

# Subset of "Illinois" state hospitals
Illinous<- HGI[ which(HGI$State== "IL") , ]
nrow(Illinous)

# Overall rating
ggplot(HGI,aes(x=Hospital.overall.rating))+geom_bar(fill='Green')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Rating") + ylab("Count ") + ggtitle("Overall Rating")
# Acute Care hospitals
ggplot(Acute_hosp,aes(x=Hospital.overall.rating))+geom_bar(fill='orange')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Rating") + ylab("Count ") + ggtitle("Rating -  Acute Care Hospitals")
# Illinois State hospitals ratings
ggplot(Illinous,aes(x=Hospital.overall.rating))+geom_bar(fill='magenta')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Rating") + ylab("Count ") + ggtitle("Rating - Illinois State Hospitals")

# Visual representation based on the key measures
# Mortality national comparison
ggplot(HGI,aes(x=HGI$Mortality.national.comparison))+geom_bar(fill='dark grey')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Rating") + ylab("Count ") + ggtitle("Mortality national comparison")
# Safety of care national comparison
ggplot(HGI,aes(x=HGI$Safety.of.care.national.comparison))+geom_bar(fill='dark grey')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Rating") + ylab("Count ") + ggtitle("Safety of care national.comparison")
# Readmission national comparison
ggplot(HGI,aes(x=HGI$Readmission.national.comparison))+geom_bar(fill='dark grey')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Rating") + ylab("Count ") + ggtitle("Readmission national comparison")
# Patient experience national comparison
ggplot(HGI,aes(x=HGI$Patient.experience.national.comparison))+geom_bar(fill='dark grey')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Rating") + ylab("Count ") + ggtitle("Patient experience national comparison")
# Effectiveness of care national comparison
ggplot(HGI,aes(x=HGI$Effectiveness.of.care.national.comparison))+geom_bar(fill='dark grey')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Rating") + ylab("Count ") + ggtitle("Effectiveness of care national comparison")
# Timeliness of care national comparison
ggplot(HGI,aes(x=HGI$Timeliness.of.care.national.comparison))+geom_bar(fill='dark grey')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Rating") + ylab("Count ") + ggtitle("Timeliness of care national comparison")
# Efficient use of medical imaging national comparison
ggplot(HGI,aes(x=HGI$Efficient.use.of.medical.imaging.national.comparison))+geom_bar(fill='dark grey')+scale_y_continuous(trans='log2') +geom_text(stat='count',aes(label=..count..),vjust=2)+ xlab("Rating") + ylab("Count ") + ggtitle("Efficient use of medical imaging national comparison")

#remove(list = ls()) #Clear the Global Environment
#Load Measures and Weights based on Unsupervised Learning
Measure_ID <- c("IMM_2",	"IMM_3_OP_27_FAC_ADHPCT",	"OP_22",	"OP_23",	"OP_29",	"OP_30",	"OP_4",	"PC_01",	"VTE_6",	"OP_10",	"OP_11",	"OP_13",	"OP_14",	"OP_8",	"OP_9",	"MORT_30_AMI",	"MORT_30_CABG",	"MORT_30_COPD",	"MORT_30_HF",	"MORT_30_PN",	"MORT_30_STK",	"PSI_4_SURG_COMP",	"H_CLEAN_LINEAR_SCORE",	"H_COMP_1_LINEAR_SCORE",	"H_COMP_2_LINEAR_SCORE",	"H_COMP_4_LINEAR_SCORE",	"H_COMP_5_LINEAR_SCORE",	"H_COMP_6_LINEAR_SCORE",	"H_COMP_7_LINEAR_SCORE",	"H_HSP_RATING_LINEAR_SCORE",	"H_QUIET_LINEAR_SCORE",	"H_RECMND_LINEAR_SCORE",	"READM_30_AMI",	"READM_30_CABG",	"READM_30_COPD",	"READM_30_HF",	"READM_30_HIP_KNEE",	"READM_30_HOSP_WIDE",	"READM_30_PN",	"READM_30_STK",	"PSI_8_POST_HIP",	"COMP_HIP_KNEE",	"HAI_1_SIR",	"HAI_2_SIR",	"HAI_3_SIR",	"HAI_4_SIR",	"HAI_5_SIR",	"HAI_6_SIR",	"PSI_13_POST_SEPSIS",	"PSI_3_ULCER",	"PSI_6_IAT_PTX",	"PSI_90_SAFETY",	"ED_1b",	"ED_2b",	"OP_18b",	"OP_20",	"OP_21",	"OP_25",	"OP_5",	"SM_SS_CHECK")
Measure_Group <- c("Efficiency of Care",	"Efficiency of Care",	"Efficiency of Care",	"Efficiency of Care",	"Efficiency of Care",	"Efficiency of Care",	"Efficiency of Care",	"Efficiency of Care",	"Efficiency of Care",	"Effective use of Medical Imaging",	"Effective use of Medical Imaging",	"Effective use of Medical Imaging",	"Effective use of Medical Imaging",	"Effective use of Medical Imaging",	"Effective use of Medical Imaging",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"Patient Experience",	"Patient Experience",	"Patient Experience",	"Patient Experience",	"Patient Experience",	"Patient Experience",	"Patient Experience",	"Patient Experience",	"Patient Experience",	"Patient Experience",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Readmission",	"Safety Of Care",	"Safety Of Care",	"Safety Of Care",	"Safety Of Care",	"Safety Of Care",	"Safety Of Care",	"Safety Of Care",	"Safety Of Care",	"Safety Of Care",	"Safety Of Care",	"Safety Of Care",	"Safety Of Care",	"Timeliness Of Care",	"Timeliness Of Care",	"Timeliness Of Care",	"Timeliness Of Care",	"Timeliness Of Care",	"Timeliness Of Care",	"Timeliness Of Care",	"Timeliness Of Care")
Ailment <- c("PreventiveCare",	"PreventiveCare",	"Emergencydepartment_throughput",	"Emergencydepartment_throughput",	"Colonoscopy",	"Colonoscopy",	"HeartAttack",	"ChildDelivery",	"BloodClotPrevention",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Efficient_Use_of_Medical_Imaging",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"Mortality",	"Surgicalcomplications",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"Patient_Experience",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"UnplannedVisits",	"Surgicalcomplications",	"Surgicalcomplications",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Safety_of_Care",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Surgicalcomplications",	"Emergencydepartment_throughput",	"Emergencydepartment_throughput",	"Emergencydepartment_throughput",	"Emergencydepartment_throughput",	"Emergencydepartment_throughput",	" Structuralmeasures",	"HeartAttack",	" Structuralmeasures")
Direction <- c("High the better",	"High the better",	"Lower the better",	"High the better",	"High the better",	"High the better",	"High the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Check",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"High the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"Lower the better",	"High the better",	"Lower the better",	"High the better")
Measure_Wt <- c("17.1",	"6.3",	"3.8",	"9.7",	"7",	"23.6",	"11.7",	"8.9",	"11.8",	"26.4",	"22.8",	"5.8",	"35.8",	"5.5",	"3.7",	"4.9",	"6.6",	"21.8",	"23",	"20.7",	"16.4",	"6.6",	"10.2",	"12.3",	"11",	"11.5",	"11.8",	"8.4",	"10.2",	"9",	"9.5",	"6.1",	"7.6",	"12.5",	"13.8",	"14.1",	"5.8",	"20.1",	"15.2",	"10.9",	"0",	"3",	"10.7",	"14.8",	"10.9",	"10.4",	"5.3",	"4.2",	"4.4",	"7",	"5.7",	"23.5",	"18.3",	"16.3",	"13.3",	"9",	"8.5",	"14.3",	"4.1",	"16.3")
measureDic <- data.frame(Measure_ID,Measure_Group,Ailment,Direction,Measure_Wt)

#Load required files for Provider Analytics
setwd("C:/Masters/PGDDS/Capstone/Base Files/Hospital_Revised_FlatFiles_20161110") #set working directory
HospGen <- read.csv("Hospital General Information.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
names(HospGen) <- gsub("\\.", "_", names(HospGen)) #Replace dots in Column Names with Underscore

HospGen <- HospGen[,-c(14,16,18,20,22,24,26,28)]

#National Level Comparison
tempDF <- sqldf("SELECT Hospital_overall_rating, count(Provider_ID) as Num_Hosp FROM HospGen
                WHERE Hospital_Type = 'Acute Care Hospitals'
                GROUP BY Hospital_overall_rating")
#Compare EVANSTON HOSPITAL with Acute Care Hospitals at National Level
ggplot(data=tempDF, aes(x=Hospital_overall_rating, y=Num_Hosp)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=Num_Hosp), vjust=1.6, color="white", size=3.5)+
  theme_minimal()

tempDF <- sqldf("SELECT Hospital_overall_rating, count(Provider_ID) as Num_Hosp FROM HospGen
                WHERE Hospital_Type = 'Acute Care Hospitals' and
                Hospital_Ownership = 'Voluntary non-profit - Other'
                GROUP BY Hospital_overall_rating")
#Compare EVANSTON HOSPITAL with Acute Care Hospitals and Voluntary non-profit - Other at National Level
ggplot(data=tempDF, aes(x=Hospital_overall_rating, y=Num_Hosp)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=Num_Hosp), vjust=1.6, color="white", size=3.5)+
  theme_minimal()

##State Level Comparison
tempDF <- sqldf("SELECT Hospital_overall_rating, count(Provider_ID) as Num_Hosp FROM HospGen
                WHERE State = 'IL' and 
                Hospital_Type = 'Acute Care Hospitals'
                GROUP BY Hospital_overall_rating")
#Compare EVANSTON HOSPITAL with Acute Care Hospitals in State IL
ggplot(data=tempDF, aes(x=Hospital_overall_rating, y=Num_Hosp)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=Num_Hosp), vjust=1.6, color="white", size=3.5)+
  theme_minimal()

tempDF <- sqldf("SELECT Hospital_overall_rating, count(Provider_ID) as Num_Hosp FROM HospGen
                WHERE State = 'IL' and 
                Hospital_Type = 'Acute Care Hospitals' and
                Hospital_Ownership = 'Voluntary non-profit - Other'
                GROUP BY Hospital_overall_rating")
#Compare EVANSTON HOSPITAL with Acute Care Hospitals and Voluntary non-profit - Other in State IL
ggplot(data=tempDF, aes(x=Hospital_overall_rating, y=Num_Hosp)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=Num_Hosp), vjust=1.6, color="white", size=3.5)+
  theme_minimal()

##Comparison within Same Distribution Group - Compaison between Evanston & Top 4 Hospitals of Acute Care and Ownership as Voluntary non-profit - Other
tempDF <- sqldf("SELECT * FROM HospGen
                WHERE State = 'IL' and 
                Hospital_Type = 'Acute Care Hospitals' and
                Hospital_Ownership = 'Voluntary non-profit - Other' and
                (Hospital_overall_rating = '4' or Provider_ID = '140010')
                ORDER BY Hospital_overall_rating")

#Get National Averages 
TempDF <- read.csv("Readmissions and Deaths - National.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
names(TempDF) <- gsub("\\.", "_", names(TempDF)) #Replace dots in Column Names with Underscore
NationalRates <- TempDF[,c("Measure_Name","Measure_ID","National_Rate")]
colnames(NationalRates)[3] <- "Score" #Rename National Rate to Score

TempDF <- read.csv("Timely and Effective Care - National.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
names(TempDF) <- gsub("\\.", "_", names(TempDF)) #Replace dots in Column Names with Underscore
TempDF <- TempDF[,c("Measure_Name","Measure_ID","Score")]
NationalRates <- smartbind(NationalRates,TempDF)

TempDF <- read.csv("Medicare Hospital Spending per Patient - National.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
names(TempDF) <- gsub("\\.", "_", names(TempDF)) #Replace dots in Column Names with Underscore
TempDF <- TempDF[,c("Measure_Name","Measure_ID","Score")]
NationalRates <- smartbind(NationalRates,TempDF)

TempDF <- read.csv("Outpatient Imaging Efficiency - National.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
names(TempDF) <- gsub("\\.", "_", names(TempDF)) #Replace dots in Column Names with Underscore
TempDF <- TempDF[,c("Measure_Name","Measure_ID","Score")]
NationalRates <- smartbind(NationalRates,TempDF)

TempDF <- read.csv("Healthcare Associated Infections - National.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
names(TempDF) <- gsub("\\.", "_", names(TempDF)) #Replace dots in Column Names with Underscore
TempDF <- TempDF[,c("Measure_Name","Measure_ID","Score")]
NationalRates <- smartbind(NationalRates,TempDF)

TempDF <- read.csv("Complications - National.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
names(TempDF) <- gsub("\\.", "_", names(TempDF)) #Replace dots in Column Names with Underscore
TempDF <- TempDF[,c("Measure_Name","Measure_ID","National_Rate")]
colnames(TempDF)[3] <- "Score" #Rename National Rate to Score
NationalRates <- smartbind(NationalRates,TempDF)

#Patient Experience
TempDF <- read.csv("HCAHPS - National.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
names(TempDF) <- gsub("\\.", "_", names(TempDF)) #Replace dots in Column Names with Underscore
PatientExpAnalysis <- TempDF[,c("HCAHPS_Measure_ID","HCAHPS_Question","HCAHPS_Answer_Percent")]
colnames(PatientExpAnalysis)[3] <- "National_Answer_Percent" #Rename National Rate to Score

TempDF <- read.csv("HCAHPS - Hospital.csv",stringsAsFactors = FALSE,header=T, na.strings=c("","NA","Not Available"))
names(TempDF) <- gsub("\\.", "_", names(TempDF)) #Replace dots in Column Names with Underscore
PatientExpDF <- sqldf("SELECT HCAHPS_Measure_ID, HCAHPS_Question,Patient_Survey_Star_Rating,HCAHPS_Answer_Percent,Number_of_Completed_Surveys,Survey_Response_Rate_Percent 
                      FROM TempDF
                      WHERE Provider_ID = '140010'")

#Combine Hospital Score and National Average in Single Data Frame for Patient Experience
PatientExpDF <- merge(x = PatientExpDF, y = PatientExpAnalysis, by = "HCAHPS_Measure_ID", all.x = TRUE)


measureDic <- merge(measureDic,NationalRates)
colnames(measureDic)[7] <- "National_Avg" #Rename Score to National_Avg"

##Comparison by Measure Scores
providerMeasureData <- sqldf("SELECT T1.Measure_Type, T2.Ailment, T1.Measure_ID,T2.Measure_Name, T1.Score as Evanston_Score, T2.Measure_Wt as Measure_Wt_Perc,T1.HBLB as Measure_Direction,T2.National_Avg 
                             FROM providerMeasureData T1, measureDic T2
                             WHERE T1.Measure_ID  = T2.Measure_ID and
                             T1.Provider_ID = '140010'")
#Write output to Excel
write.xlsx(PatientExpDF, "C:/Masters/PGDDS/Capstone/Template/Patient_Exp_Analysis.xlsx")#Patient Experience Score Comparison to National Avg
write.xlsx(providerMeasureData, "C:/Masters/PGDDS/Capstone/Template/EvanstonMeasureAnalysis.xlsx")#Evanston Score Comparison to National Avg

#Safety Of Care
tempDF <- subset(providerMeasureData, providerMeasureData$Measure_Type == "Safety_of_Care")
ggplot(data = tempDF, mapping = aes(x = factor(Measure_ID), y = Measure_Wt_Perc,fill=factor(Measure_Wt_Perc))) + geom_boxplot()  + 
  coord_flip() + labs(y='Measure_Wt_Perc',x='Measure_ID') #Show Weights

#Plot Evanston Score
ggplot(data=tempDF, aes(x=Measure_ID, y=Evanston_Score, fill=Evanston_Score)) + 
  geom_bar(colour="black", stat="identity",
           position=position_dodge(),
           size=.3) +                        # Thinner lines
  scale_fill_hue(name="Evanston_Score") +    # Set legend title
  xlab("Measure") + ylab("Evanston Score") + # Set axis labels
  ggtitle("Safety of Care") +     # Set title
  theme_bw()

#Timeliness Of Care
tempDF <- subset(providerMeasureData, providerMeasureData$Measure_Type == "Timeliness_of_Care")
ggplot(data = tempDF, mapping = aes(x = factor(Measure_ID), y = Measure_Wt_Perc,fill=factor(Measure_Wt_Perc))) + geom_boxplot()  + 
  coord_flip() + labs(y='Measure_Wt_Perc',x='Measure_ID') #Show Weights

#Plot Evanston Score
ggplot(data=tempDF, aes(x=Measure_ID, y=Evanston_Score, fill=Evanston_Score)) + 
  geom_bar(colour="black", stat="identity",
           position=position_dodge(),
           size=.3) +                        # Thinner lines
  scale_fill_hue(name="Evanston_Score") +    # Set legend title
  xlab("Measure") + ylab("Evanston Score") + # Set axis labels
  ggtitle("Timeliness Of Care") +     # Set title
  theme_bw()

#Mortality
tempDF <- subset(providerMeasureData, providerMeasureData$Measure_Type == "Mortality")
ggplot(data = tempDF, mapping = aes(x = factor(Measure_ID), y = Measure_Wt_Perc,fill=factor(Measure_Wt_Perc))) + geom_boxplot()  + 
  coord_flip() + labs(y='Measure_Wt_Perc',x='Measure_ID') #Show Weights

#Plot Evanston Score
ggplot(data=tempDF, aes(x=Measure_ID, y=Evanston_Score, fill=Evanston_Score)) + 
  geom_bar(colour="black", stat="identity",
           position=position_dodge(),
           size=.3) +                        # Thinner lines
  scale_fill_hue(name="Evanston_Score") +    # Set legend title
  xlab("Measure") + ylab("Evanston Score") + # Set axis labels
  ggtitle("Mortality") +     # Set title
  theme_bw()

#Efficient_Use_of_Medical_Imaging
tempDF <- subset(providerMeasureData, providerMeasureData$Measure_Type == "Efficient_Use_of_Medical_Imaging")
ggplot(data = tempDF, mapping = aes(x = factor(Measure_ID), y = Measure_Wt_Perc,fill=factor(Measure_Wt_Perc))) + geom_boxplot()  + 
  coord_flip() + labs(y='Measure_Wt_Perc',x='Measure_ID') #Show Weights

#Plot Evanston Score
ggplot(data=tempDF, aes(x=Measure_ID, y=Evanston_Score, fill=Evanston_Score)) + 
  geom_bar(colour="black", stat="identity",
           position=position_dodge(),
           size=.3) +                        # Thinner lines
  scale_fill_hue(name="Evanston_Score") +    # Set legend title
  xlab("Measure") + ylab("Evanston Score") + # Set axis labels
  ggtitle("Efficient_Use_of_Medical_Imaging") +     # Set title
  theme_bw()

#Readmission
tempDF <- subset(providerMeasureData, providerMeasureData$Measure_Type == "Readmission")
ggplot(data = tempDF, mapping = aes(x = factor(Measure_ID), y = Measure_Wt_Perc,fill=factor(Measure_Wt_Perc))) + geom_boxplot()  + 
  coord_flip() + labs(y='Measure_Wt_Perc',x='Measure_ID') #Show Weights

#Plot Evanston Score
ggplot(data=tempDF, aes(x=Measure_ID, y=Evanston_Score, fill=Evanston_Score)) + 
  geom_bar(colour="black", stat="identity",
           position=position_dodge(),
           size=.3) +                        # Thinner lines
  scale_fill_hue(name="Evanston_Score") +    # Set legend title
  xlab("Measure") + ylab("Evanston Score") + # Set axis labels
  ggtitle("Readmission") +     # Set title
  theme_bw()


#Readmission
tempDF <- subset(providerMeasureData, providerMeasureData$Measure_Type == "Readmission")
ggplot(data = tempDF, mapping = aes(x = factor(Measure_ID), y = Measure_Wt_Perc,fill=factor(Measure_Wt_Perc))) + geom_boxplot()  + 
  coord_flip() + labs(y='Measure_Wt_Perc',x='Measure_ID') #Show Weights

#Plot Evanston Score
ggplot(data=tempDF, aes(x=Measure_ID, y=Evanston_Score, fill=Evanston_Score)) + 
  geom_bar(colour="black", stat="identity",
           position=position_dodge(),
           size=.3) +                        # Thinner lines
  scale_fill_hue(name="Evanston_Score") +    # Set legend title
  xlab("Measure") + ylab("Evanston Score") + # Set axis labels
  ggtitle("Safety of Care") +     # Set title
  theme_bw()

#Effectiveness_of_Care
tempDF <- subset(providerMeasureData, providerMeasureData$Measure_Type == "Effectiveness_of_Care")
ggplot(data = tempDF, mapping = aes(x = factor(Measure_ID), y = Measure_Wt_Perc,fill=factor(Measure_Wt_Perc))) + geom_boxplot()  + 
  coord_flip() + labs(y='Measure_Wt_Perc',x='Measure_ID') #Show Weights

#Plot Evanston Score
ggplot(data=tempDF, aes(x=Measure_ID, y=Evanston_Score, fill=Evanston_Score)) + 
  geom_bar(colour="black", stat="identity",
           position=position_dodge(),
           size=.3) +                        # Thinner lines
  scale_fill_hue(name="Evanston_Score") +    # Set legend title
  xlab("Measure") + ylab("Evanston Score") + # Set axis labels
  ggtitle("Effectiveness_of_Care") +     # Set title
  theme_bw()

#######################################################################################################
#############################################End of Part 3#############################################
#######################################################################################################

